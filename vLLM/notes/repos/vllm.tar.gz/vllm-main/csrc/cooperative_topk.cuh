/*
 * Cooperative TopK kernel for DSA Indexer
 */

#ifndef COOPERATIVE_TOPK_CUH_
#define COOPERATIVE_TOPK_CUH_

#include <cooperative_groups.h>
#include <cuda.h>
#include <cuda_fp16.h>
#include <cuda_runtime.h>
#include <cuda/ptx>
#include <algorithm>
#include <cstdint>
#include <type_traits>

#include "topk_histogram_4096.cuh"
#include "topk_histogram_4096_overflow.cuh"

namespace vllm {
namespace cooperative {

namespace hist4096 = topk_histogram_4096;

constexpr uint32_t kHistBits = 10;
constexpr uint32_t kHistBins = 1 << kHistBits;
using ExactRadix = hist4096::ExactRadixTraits;
constexpr uint32_t kExactHistBins = ExactRadix::kBins;
constexpr uint32_t kMaxTopK = 2048;
// Retain this many threshold-bin candidates before exact recovery.
constexpr uint32_t kCoarseTieCapacity = kMaxTopK;

constexpr uint32_t kElemPerStage = 16;
constexpr uint32_t kSizePerStage =
    kElemPerStage * hist4096::kBlockSize;  // 16384

// CS=4 two-pass path uses two TMA stages as a double buffer.
constexpr uint32_t kStreamingStagesCS4 = 2;
// BF16 stages take half the bytes, so the same smem holds twice as many.
template <typename InT>
constexpr uint32_t kStagesPerFp32Stage = sizeof(float) / sizeof(InT);
// CS=8/16 fused paths keep all loaded TMA stages resident in smem.
template <typename InT>
constexpr uint32_t kFusedStagesCS8 = 2 * kStagesPerFp32Stage<InT>;
template <typename InT>
constexpr uint32_t kFusedStagesCS16 = kFusedStagesCS8<InT>;

// CS=4 single-pass path: 49152 FP32 or 98304 BF16 elements per block
template <typename InT>
constexpr uint32_t kMaxSinglePassStages = 3 * kStagesPerFp32Stage<InT>;

// Elements per 16-byte TMA unit: rows, per-block slices and copy sizes are
// aligned to this.
template <typename InT>
constexpr uint32_t kTmaAlign = 16 / sizeof(InT);

template <uint32_t TopK = 1024, typename InT = float>
struct CooperativeTopKParams {
  const InT* __restrict__ input;
  int32_t* __restrict__ output;
  const int32_t* __restrict__ lengths;
  hist4096::Tie* __restrict__ tie_ws;  // per-row tie workspace, see
                                       // kTieWsPerRow
  uint32_t num_rows, stride;
};

// ============================================================================
// Cooperative helpers
// ============================================================================

// only CS adjacent lanes participate (sub-warp reduce), in opposite to
// warp_reduce_sum_full
template <uint32_t N>
__device__ __forceinline__ uint32_t warp_reduce_sum_subN(uint32_t v) {
#pragma unroll
  for (uint32_t m = N >> 1; m > 0; m >>= 1)
    v += __shfl_xor_sync(0xFFFFFFFF, v, m, 32);
  return v;
}

// ============================================================================
// Helpers
// ============================================================================

__device__ __forceinline__ uint32_t extract_coarse_bin(float x) {
  return hist4096::extract_coarse_bin_N<kHistBits>(x);
}

// Visit a staged chunk's scores as (index in chunk, coarse bin, score). BF16
// is read two scores per 32-bit load.
template <uint32_t kBits, typename InT, typename Visit>
__device__ __forceinline__ void for_each_staged_score(const InT* buf,
                                                      uint32_t sz,
                                                      Visit visit) {
  const auto tx = threadIdx.x;
  if constexpr (std::is_same_v<InT, __nv_bfloat16>) {
    const auto* words = reinterpret_cast<const uint32_t*>(buf);
#pragma unroll
    for (uint32_t i = 0; i < kElemPerStage / 2; i++) {
      const auto li = 2 * (tx + i * hist4096::kBlockSize);
      if (li >= sz) {
        break;
      }
      const uint32_t w = words[li / 2];
      const auto bins = hist4096::extract_coarse_bins_bf16x2<kBits>(w);
      visit(li, bins.x, __uint_as_float(w << 16));
      if (li + 1 < sz) {
        visit(li + 1, bins.y, __uint_as_float(w & 0xFFFF0000u));
      }
    }
  } else {
#pragma unroll
    for (uint32_t i = 0; i < kElemPerStage; i++) {
      const auto li = tx + i * hist4096::kBlockSize;
      if (li >= sz) {
        break;
      }
      const float sc = buf[li];
      visit(li, hist4096::extract_coarse_bin_N<kBits>(sc), sc);
    }
  }
}

__device__ __forceinline__ void mbarrier_init(uint64_t* a, uint32_t n) {
  cuda::ptx::mbarrier_init(a, n);
}
__device__ __forceinline__ void mbarrier_wait(uint64_t* a, uint32_t p) {
  while (!cuda::ptx::mbarrier_try_wait_parity(cuda::ptx::sem_relaxed,
                                              cuda::ptx::scope_cta, a, p));
}
__device__ __forceinline__ void mbarrier_arrive_expect_tx(uint64_t* a,
                                                          uint32_t t) {
  cuda::ptx::mbarrier_arrive_expect_tx(cuda::ptx::sem_relaxed,
                                       cuda::ptx::scope_cta,
                                       cuda::ptx::space_shared, a, t);
}
__device__ __forceinline__ void tma_load(void* d, const void* s, uint32_t n,
                                         uint64_t* m) {
  cuda::ptx::cp_async_bulk(cuda::ptx::space_shared, cuda::ptx::space_global, d,
                           s, n, m);
}

// ============================================================================
// DSMEM histogram reduce
// ============================================================================

template <uint32_t CS, uint32_t NumBins>
__device__ __forceinline__ void dsmem_hist_reduce(uint32_t* histogram) {
  static_assert(NumBins % CS == 0);
  // Fold the distributed per-rank bins into cluster-visible totals.
  auto cluster = cooperative_groups::this_cluster();
  cluster.sync();
  const auto tx = threadIdx.x;
  const auto rank = blockIdx.y;
  constexpr auto kLocal = NumBins / CS;
  const auto off = kLocal * rank;
#pragma unroll
  for (uint32_t bin = tx; bin < NumBins; bin += hist4096::kBlockSize) {
    // Cover histograms wider than one CTA without changing the reduction.
    const auto addr = &histogram[off + bin / CS];
    const auto src = cluster.map_shared_rank(addr, bin % CS);
    *src = warp_reduce_sum_subN<CS>(*src);
  }
  cluster.sync();
}

// ============================================================================
// Find threshold from reduced histogram
// ============================================================================

// NOTE: caller must ensure a cluster.sync() or __syncthreads() happened
// before calling this, so warp_sum writes are visible across warps.
// The first internal __syncthreads() is still needed for the warp_sum exchange.
template <uint32_t TopK>
__device__ __forceinline__ void find_threshold(uint32_t* histogram,
                                               uint32_t* warp_sum,
                                               uint32_t* counter_gt,
                                               uint32_t* counter_eq,
                                               hist4096::MatchBin* match) {
  const auto tx = threadIdx.x;
  const auto li = tx % hist4096::kWarpSize, wi = tx / hist4096::kWarpSize;
  const auto value = tx < kHistBins ? histogram[tx] : 0;
  const auto winc = hist4096::warp_inclusive_sum(li, value);
  if (li == hist4096::kWarpSize - 1) warp_sum[wi] = winc;
  __syncthreads();
  const auto tmp = warp_sum[li];
  const auto total = hist4096::warp_reduce_sum_full(tmp);
  auto pfx = hist4096::warp_reduce_sum_full(li < wi ? tmp : 0) + winc;
  const auto above = total - pfx;
  if (tx < kHistBins && above < TopK && above + value >= TopK) {
    *counter_gt = *counter_eq = 0;
    *match = {.bin = tx, .above_count = above, .equal_count = value};
  }
  __syncthreads();
}

// Streams data through shared memory in chunks, processing each chunk before
// loading the next overwrites each buffer after processing it (the epilogue
// prefetch loads the next chunk into the same slot)
template <typename SmemType, uint32_t kStages, uint32_t kBinBits,
          bool kIsScatter, typename InT>
__device__ void tma_stream_pass(const InT* scores, uint32_t length,
                                uint32_t thr_bin, int32_t* indices,
                                uint32_t* phases, SmemType* smem) {
  const auto tx = threadIdx.x;
  const auto lane = tx % hist4096::kWarpSize;
  const auto ni =
      (length + kSizePerStage - 1) / kSizePerStage;  // total stages needed
  constexpr uint32_t kAlign = kTmaAlign<InT>;
  const auto la = (length + kAlign - 1) &
                  ~(kAlign - 1);  // length rounded up to 16B (TMA alignment)
  const auto pass =
      kIsScatter ? 1 : 0;  // barrier dim: [0] for histogram, [1] for scatter

  // Prologue: issue initial TMA loads - prefill the pipeline
  if (tx == 0) {
#pragma unroll
    for (uint32_t i = 0; i < kStages; i++) {
      if (i >= ni) {
        break;
      }
      const auto o = i * kSizePerStage;
      const auto sz = min(kSizePerStage, la - o) * sizeof(InT);
      tma_load(smem->score_buffer[i], scores + o, sz,
               &smem->barrier[pass][i]);  // cp.async.bulk is non-blocking
      mbarrier_arrive_expect_tx(&smem->barrier[pass][i], sz);
    }
  }

  // Main loop: process stages
  for (uint32_t it = 0; it < ni; it++) {
    const auto b = it % kStages;  // which buffer slot (0 or 1)
    const auto o = it * kSizePerStage;
    const auto sz = min(kSizePerStage, length - o);

    if (lane == 0) {
      mbarrier_wait(&smem->barrier[pass][b],
                    phases[b] & 1);  // wait for the data
    }
    phases[b]++;  // advances the phase for next time this slot is reused
    __syncwarp();

    for_each_staged_score<kBinBits>(
        smem->score_buffer[b], sz, [&](uint32_t li, uint32_t bn, float sc) {
          if constexpr (kIsScatter) {  // compile-time branch
            // Scatter pass: place above-threshold and collect ties
            const auto gi = o + li;
            if (bn > thr_bin) {
              indices[atomicAdd(&smem->counter_gt, 1)] = gi;
            } else if (bn == thr_bin) {
              const auto p = atomicAdd(&smem->counter_eq, 1);
              if (p < kCoarseTieCapacity) {
                smem->tie_buffer[p] = {gi, sc};
              }
            }
          } else {
            // Histogram pass: just count
            atomicAdd(&smem->histogram[bn], 1);
          }
        });
    __syncthreads();  // ensures all threads finished processing their buffer
                      // before next TMA load

    // Epilogue: issue next TMA load
    if (tx == 0 && it + kStages < ni) {
      const auto no = (it + kStages) * kSizePerStage;
      const auto nsz = min(kSizePerStage, la - no) * sizeof(InT);
      tma_load(smem->score_buffer[b], scores + no, nsz,
               &smem->barrier[pass][b]);
      mbarrier_arrive_expect_tx(&smem->barrier[pass][b], nsz);
    }
  }
}

// ============================================================================
// Fused path: single TMA pass, rescan smem for scatter
// ============================================================================

// Fused shared memory layout for cluster cooperative paths.
// kPasses=1 for single-pass (CS=8, CS=4 singlepass), kPasses=2 for two-pass
// (CS=4).
template <uint32_t kStages, uint32_t kPasses = 1, typename InT = float>
struct SmemFused {
  uint64_t barrier[kPasses][kStages];
  alignas(128) uint32_t counter_gt;
  alignas(128) uint32_t counter_eq;
  alignas(128) hist4096::MatchBin match;
  uint32_t warp_sum[hist4096::kNumWarps];
  union {
    uint32_t histogram[kExactHistBins];
    hist4096::Tie tie_buffer[kMaxTopK];
  };
  alignas(128) InT score_buffer[kStages][kSizePerStage];
};

template <typename InT>
using Smem4 = SmemFused<kStreamingStagesCS4, 2, InT>;
template <typename InT>
using SmemSinglePass = SmemFused<kMaxSinglePassStages<InT>, 1, InT>;

#include "cooperative_topk_overflow.cuh"

// Cluster-cooperative large path.
// kFused=true: all TMA stages resident, single-pass histogram + scatter (rescan
// from smem). kFused=false: TMA double-buffer streaming, two passes (histogram
// then scatter).
template <uint32_t TopK, uint32_t CS, typename SmemType, bool kFused,
          typename InT>
__device__ void large_topk(const InT* __restrict__ row_input,
                           int32_t* __restrict__ row_output, uint32_t seq_len,
                           uint32_t* phases, hist4096::Tie* tie_ws) {
  const auto rank = blockIdx.y;  // this block's position in cluster
  const auto tx = threadIdx.x;
  const auto lane = tx % hist4096::kWarpSize;

  extern __shared__ __align__(128) uint8_t smem_raw[];
  auto* smem = reinterpret_cast<SmemType*>(smem_raw);
  int32_t* s_topk = reinterpret_cast<int32_t*>(smem_raw + sizeof(SmemType));

  // Partition row across cluster ranks
  constexpr uint32_t kAlign = kTmaAlign<InT>;
  const auto units =
      (seq_len + kAlign - 1) / kAlign;  // 16B-aligned element count
  const auto base = units / CS, extra = units % CS;  // elements per block
  const auto lu = base + (rank < extra ? 1u : 0u);   // remainder blocks
  const auto ou =
      rank * base + min(rank, extra);  // this block's count (load-balanced)
  const auto my_start = ou * kAlign;   // global start offset
  const auto my_len = min(my_start + lu * kAlign, seq_len) -
                      my_start;  // actual length of this block
  const auto num_iters =
      (my_len + kSizePerStage - 1) / kSizePerStage;  // TMA stages needed
  const auto len_aligned = (my_len + kAlign - 1) & ~(kAlign - 1);

  if constexpr (kFused) {
    // Fused init + TMA prologue
    if (tx < kHistBins) {
      smem->histogram[tx] = 0;  // all threads zero histogram
    }
    if (tx == 0) {  // thread 0 issues TMA - then all threads continue working
                    // until mbarrier sync
      smem->counter_gt = 0;
      smem->counter_eq = 0;
      for (uint32_t i = 0; i < num_iters; i++) {
        const auto off = i * kSizePerStage;
        const auto sz = min(kSizePerStage, len_aligned - off) * sizeof(InT);
        tma_load(smem->score_buffer[i], row_input + my_start + off, sz,
                 &smem->barrier[0][i]);  // cp.async.bulk of size kSizePerStage
                                         // × sizeof(InT)
        mbarrier_arrive_expect_tx(&smem->barrier[0][i], sz);
      }
    }
    __syncthreads();

    // Histogram build. ILP unroll-by-2, no inter-stage sync
    for (uint32_t iter = 0; iter < num_iters; iter++) {
      const auto off = iter * kSizePerStage;
      const auto sz = min(kSizePerStage, my_len - off);
      if (lane == 0) {
        mbarrier_wait(&smem->barrier[0][iter],
                      phases[iter] & 1);  // wait for TMA
      }
      phases[iter]++;
      __syncwarp();
      if constexpr (std::is_same_v<InT, __nv_bfloat16>) {
        for_each_staged_score<kHistBits>(smem->score_buffer[iter], sz,
                                         [&](uint32_t, uint32_t bin, float) {
                                           atomicAdd(&smem->histogram[bin], 1);
                                         });
      } else {
#pragma unroll
        for (uint32_t i = 0; i < kElemPerStage; i += 2) {
          const auto li0 = tx + i * hist4096::kBlockSize;
          const auto li1 = tx + (i + 1) * hist4096::kBlockSize;
          if (li0 >= sz) {
            break;
          }
          const auto b0 = extract_coarse_bin(smem->score_buffer[iter][li0]);
          if (li1 < sz) {
            const auto b1 = extract_coarse_bin(smem->score_buffer[iter][li1]);
            atomicAdd(&smem->histogram[b0], 1);
            atomicAdd(&smem->histogram[b1], 1);
          } else {
            atomicAdd(&smem->histogram[b0], 1);
          }
        }
      }
    }
  } else {
    // Twopass: init then stream histogram pass
    if (tx < kHistBins) {
      smem->histogram[tx] = 0;
    }
    if (tx == 0) {
      smem->counter_gt = 0;
      smem->counter_eq = 0;
    }
    __syncthreads();
    tma_stream_pass<SmemType, kStreamingStagesCS4, kHistBits, false, InT>(
        row_input + my_start, my_len, 0, nullptr, phases, smem);
  }

  // DSMEM all-reduce + find threshold
  dsmem_hist_reduce<CS, kHistBins>(
      smem->histogram);  // each block histogram is summed across all CS blocks
  find_threshold<TopK>(smem->histogram, smem->warp_sum, &smem->counter_gt,
                       &smem->counter_eq, &smem->match);

  const auto thr = smem->match.bin;
  // A threshold bin beyond tie capacity needs exact recovery; scattering
  // into the bounded buffer would discard possible TopK candidates.
  if (__builtin_expect(smem->match.equal_count > kCoarseTieCapacity, 0)) {
    recover_coarse_overflow<TopK, CS, kFused>(row_input, row_output, seq_len,
                                              my_start, my_len, smem, s_topk);
    return;
  }

  if constexpr (kFused) {
    // Fused scatter: rescan score_buffer (still in smem)
    for (uint32_t iter = 0; iter < num_iters; iter++) {
      const auto off = iter * kSizePerStage;
      const auto sz = min(kSizePerStage, my_len - off);
      for_each_staged_score<kHistBits>(  // still in smem
          smem->score_buffer[iter], sz,
          [&](uint32_t li, uint32_t bin, float score) {
            const auto gidx = off + li;
            if (bin > thr) {
              s_topk[atomicAdd(&smem->counter_gt, 1)] = gidx;  // above
            } else if (bin == thr) {
              const auto p = atomicAdd(&smem->counter_eq,
                                       1);  // equal -> ties (later refinement)
              if (p < kCoarseTieCapacity) {
                smem->tie_buffer[p] = {gidx, score};
              }
            }
          });
    }
    __syncthreads();
  } else {
    // Twopass scatter: re-stream data via TMA
    uint32_t scatter_phases[kStreamingStagesCS4] = {0, 0};
    tma_stream_pass<SmemType, kStreamingStagesCS4, kHistBits, true, InT>(
        row_input + my_start, my_len, thr, s_topk, scatter_phases, smem);
  }

  // Output collection via DSMEM prefix sum
  constexpr uint32_t kAboveBits = 16;
  constexpr uint32_t kAboveMask = (1 << kAboveBits) - 1;
  // A block's above-threshold count is below TopK, like the whole row's.
  static_assert(kAboveMask >= TopK);

  const uint32_t la = smem->counter_gt;
  const uint32_t le_full = smem->counter_eq;
  const uint32_t le =
      min(le_full, kCoarseTieCapacity);  // written smem tie_buffer entries

  __shared__ uint32_t s_local_counts[CS];
  __shared__ uint32_t s_prefix_packed;
  __shared__ uint32_t s_total_above, s_total_equal;

  auto cluster = cooperative_groups::this_cluster();
  if (tx < CS) {
    // Pack written tie counts into 32-bit: (equal << 16) | above.
    // `le_full` may exceed the per-block tie buffer cap; using it here creates
    // holes in tie_ws and can make TopK=2048 refine unwritten workspace slots.
    const uint32_t packed = (le << kAboveBits) | la;
    const auto dst = cluster.map_shared_rank(s_local_counts, tx);
    dst[rank] = packed;  // write my count to every block's s_local_counts[rank]
  }
  cluster.sync();

  // Thread 0 computes serial prefix sum
  if (tx == 0) {
    uint32_t prefix = 0, ta = 0, te = 0;
    for (uint32_t i = 0; i < CS; i++) {
      if (i == rank) {
        s_prefix_packed = prefix;  // my prefix
      }
      ta += s_local_counts[i] & kAboveMask;   // total above
      te += s_local_counts[i] >> kAboveBits;  // total equal
      prefix += s_local_counts[i];
    }
    s_total_above = ta;
    s_total_equal = te;
  }
  __syncthreads();

  const uint32_t prefix_above = s_prefix_packed & kAboveMask;
  const uint32_t prefix_equal = s_prefix_packed >> kAboveBits;

  // Write to global output
  for (uint32_t i = tx; i < la; i += hist4096::kBlockSize) {
    // indices are placed contiguously starting at prefix_above
    row_output[prefix_above + i] =
        s_topk[i] + my_start;  // my_start: block-local -> row-global index
  }
  for (uint32_t i = tx; i < le; i += hist4096::kBlockSize) {
    const auto t = smem->tie_buffer[i];
    const uint32_t p = s_total_above + prefix_equal + i;
    if (p < TopK) {
      row_output[p] = t.idx + my_start;
    }
    const uint32_t tp = prefix_equal + i;
    if (tp < kCoarseTieCapacity) {
      tie_ws[tp] = hist4096::Tie{t.idx + my_start, t.score};
    }
  }

  // Tie refinement
  cooperative_groups::this_cluster().sync();
  if (rank != 0) {  // only rank 0 does tie refinement
    return;
  }
  if (s_total_above + s_total_equal <= TopK) {  // no ties to refine
    return;
  }

  // Tie-breaking uses the FP32 ordered key (radix-256 rounds)
  if constexpr (TopK <= hist4096::kBlockSize) {
    if (s_total_equal <= hist4096::kMaxTies) {
      // copy ties from tie_ws back to smem, then refine
      const uint32_t num_ties = s_total_equal;
      // TODO (roberto): could vectorize with uint2 (8 bytes = exactly one Tie)
      for (uint32_t i = tx; i < num_ties; i += hist4096::kBlockSize) {
        smem->tie_buffer[i] = hist4096::Tie{tie_ws[i].idx, tie_ws[i].score};
      }
      __syncthreads();
      hist4096::tie_handle<TopK>(smem->tie_buffer, num_ties, s_total_above,
                                 row_output, smem);
    } else {
      // The fast refiner fits one tie per thread; use the extended refiner
      // when the threshold bin exceeds that capacity.
      hist4096::tie_handle_large<TopK, kCoarseTieCapacity>(
          tie_ws, s_total_equal, s_total_above, row_output, smem);
    }
  } else {
    // TopK=2048: process directly from tie_ws (GMEM)
    hist4096::tie_handle_large<TopK>(tie_ws, s_total_equal, s_total_above,
                                     row_output, smem);
  }
}

// ============================================================================
// Adapted from https://github.com/sgl-project/sglang/pull/23600
// sgl-project/sglang
// (python/sglang/jit_kernel/include/sgl_kernel/deepseek_v4/topk/)
// ============================================================================

template <uint32_t TopK, uint32_t CS, typename InT>
__device__ void cooperative_topk_body(CooperativeTopKParams<TopK, InT> params) {
  const auto rank = blockIdx.y, row = blockIdx.x, tx = threadIdx.x;
  // Clamp at 0: `sl` is compared signed here but cast to uint32 below, so a
  // negative length would otherwise emit indices 0..TopK-1 as valid instead
  // of the -1 padding.
  const int32_t sl = params.lengths[row] > 0 ? params.lengths[row] : 0;
  int32_t* out = params.output + row * TopK;
  const InT* in = params.input + row * params.stride;

  // Trivial: seq_len <= TopK
  if (sl <= static_cast<int32_t>(TopK)) {
    if (rank == 0) {
      for (uint32_t i = tx; i < TopK; i += hist4096::kBlockSize) {
        out[i] = (i < static_cast<uint32_t>(sl)) ? static_cast<int32_t>(i) : -1;
      }
    }
    return;
  }

  // Short-Medium path: histogram_4096_topk on rank 0 only - all data fits in RF
  if (sl <= static_cast<int32_t>(hist4096::kHist4096MaxLen)) {
    if (rank == 0) {
      extern __shared__ __align__(128) uint8_t sr[];
      hist4096::histogram_4096_topk<
          TopK, 12, hist4096::kHist4096VecsPerThread, false,
          hist4096::OverflowRecovery::kFp32Rescan, InT>(
          in, out, sl, sr);  // 4096-bin (12-bit) histogram
    }
    return;
  }

  // Large path: init mbarriers + state, then dispatch fused or twopass.
  // Elements per block, sized by the row's length rather than its stride so a
  // short row in a wide logits buffer still takes the single-pass staging.
  // large_topk splits the row in 16-byte units, but kFusedMax and
  // kSizePerStage are multiples of that unit, so the path and stage count
  // come out the same.
  const uint32_t per_block = (static_cast<uint32_t>(sl) + CS - 1) / CS;
  constexpr uint32_t kFusedMax =
      ((CS == 16)  ? kFusedStagesCS16<InT>
       : (CS == 8) ? kFusedStagesCS8<InT>
                   : kMaxSinglePassStages<InT>)*kSizePerStage;
  const bool use_singlepass =
      per_block <=
      kFusedMax;  // single pass or TMA streaming: histogram+scatter

  // Select smem type and stage count at compile time based on CS
  constexpr uint32_t kFusedStages = (CS == 16)  ? kFusedStagesCS16<InT>
                                    : (CS == 8) ? kFusedStagesCS8<InT>
                                                : kMaxSinglePassStages<InT>;
  using FusedSmem = SmemFused<kFusedStages, 1, InT>;

  extern __shared__ __align__(128) uint8_t sr[];

  constexpr uint32_t kTieWsPerRow = kCoarseTieCapacity;
  hist4096::Tie* row_tie_ws = params.tie_ws + row * kTieWsPerRow;

  if (use_singlepass) {
    auto* smem = reinterpret_cast<FusedSmem*>(sr);
    const uint32_t sp_stages = (per_block + kSizePerStage - 1) / kSizePerStage;
    if (tx < sp_stages) {
      mbarrier_init(&smem->barrier[0][tx],
                    1);  // init 1 barrier per TMA stage -
                         // signal when async copies complete
    }
    __syncthreads();
    uint32_t phases[kFusedStages] =
        {};  // tracks the parity for mbarrier wait/arrive protocol
    large_topk<TopK, CS, FusedSmem, true, InT>(in, out, sl, phases, row_tie_ws);
  } else {
    // Streaming path for cluster sizes whose per-block input exceeds the
    // single-pass staging capacity.
    auto* smem = reinterpret_cast<Smem4<InT>*>(sr);
    if (tx < 2 * kStreamingStagesCS4) {
      mbarrier_init(&smem->barrier[0][tx],
                    1);  // init 2×2=4 barriers (2 passes × 2 stages)
    }
    __syncthreads();
    uint32_t hp[kStreamingStagesCS4] = {0,
                                        0};  // histogram+scatter pass counters
    large_topk<TopK, CS, Smem4<InT>, false, InT>(in, out, sl, hp, row_tie_ws);
  }
}

template <uint32_t TopK, typename InT>
__global__ void __launch_bounds__(hist4096::kBlockSize, 1)
    __cluster_dims__(1, 2, 1)
        cooperative_topk_cs2(CooperativeTopKParams<TopK, InT> params) {
  cooperative_topk_body<TopK, 2, InT>(params);
}

template <uint32_t TopK, typename InT>
__global__ void __launch_bounds__(hist4096::kBlockSize, 1)
    __cluster_dims__(1, 4, 1)
        cooperative_topk_cs4(CooperativeTopKParams<TopK, InT> params) {
  cooperative_topk_body<TopK, 4, InT>(params);
}

template <uint32_t TopK, typename InT>
__global__ void __launch_bounds__(hist4096::kBlockSize, 1)
    __cluster_dims__(1, 8, 1)
        cooperative_topk_cs8(CooperativeTopKParams<TopK, InT> params) {
  cooperative_topk_body<TopK, 8, InT>(params);
}

template <uint32_t TopK, typename InT>
__global__ void __launch_bounds__(hist4096::kBlockSize, 1)
    __cluster_dims__(1, 16, 1)
        cooperative_topk_cs16(CooperativeTopKParams<TopK, InT> params) {
  cooperative_topk_body<TopK, 16, InT>(params);
}

template <typename InT>
constexpr size_t kSmemSize4 = (sizeof(Smem4<InT>) > sizeof(SmemSinglePass<InT>)
                                   ? sizeof(Smem4<InT>)
                                   : sizeof(SmemSinglePass<InT>)) +
                              sizeof(int32_t) * 2048 + 128;
template <typename InT>
constexpr size_t kSmemSize2 = kSmemSize4<InT>;
template <typename InT>
constexpr size_t kSmemSize8 = sizeof(SmemFused<kFusedStagesCS8<InT>, 1, InT>) +
                              sizeof(int32_t) * 2048 + 128;

}  // namespace cooperative

}  // namespace vllm

#endif  // COOPERATIVE_TOPK_CUH_
