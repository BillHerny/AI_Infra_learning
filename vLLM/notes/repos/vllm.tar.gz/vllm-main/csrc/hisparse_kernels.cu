// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright contributors to the vLLM project
//
// HiSparse decode hot-buffer kernels for sparse MLA (GLM-5 / DeepSeek-V3.2).
//
// The swap-in algorithm is a port of SGLang's hisparse
// load_cache_to_device_buffer kernel (sgl jit_kernel/csrc/hisparse.cuh),
// adapted to vLLM addressing:
//  - tokens are keyed by their global KV slot id (block_table-converted
//    indexer output) instead of in-request positions, so no per-request
//    host-location table is needed: host pool row i is global slot i.
//  - each request state owns a fixed region of `hot_size` LRU-managed hot
//    rows.
//
// The kernels only move bytes; they are dtype agnostic.

#include "torch_utils.h"
#include "ops.h"

#include <algorithm>
#include <cstdint>
#include <optional>
#include <vector>

#include <torch/csrc/stable/c/shim.h>
#include <torch/csrc/stable/ops.h>
#include <torch/headeronly/version.h>

namespace {

constexpr int kWarpSize = 32;
// Empty key in the shared open-addressing table of host rows.
constexpr int32_t kHashEmpty = -1;

bool is_pinned_cpu_tensor(const torch::stable::Tensor& tensor) {
  cudaPointerAttributes attributes{};
  const auto status =
      cudaPointerGetAttributes(&attributes, tensor.const_data_ptr());
  if (status != cudaSuccess) {
    cudaGetLastError();
    return false;
  }
  return attributes.type == cudaMemoryTypeHost;
}

__device__ __forceinline__ int32_t hash_slot(int32_t key, int size) {
  // Knuth multiplicative hash scaled onto [0, size) by a multiply-high, so
  // the table can take any size without a division.
  return static_cast<int32_t>(
      __umulhi(static_cast<uint32_t>(key) * 2654435761u, size));
}

__device__ __forceinline__ int next_slot(int h, int size) {
  return h + 1 == size ? 0 : h + 1;
}

// Copy one row of `row_bytes` bytes with a single warp, 16 bytes at a time
// when the addresses allow it, else 4 bytes or 1 byte at a time.
__device__ __forceinline__ void copy_row_warp(int lane_id, const char* src,
                                              char* dst, int64_t row_bytes) {
  const auto alignment = reinterpret_cast<uintptr_t>(src) |
                         reinterpret_cast<uintptr_t>(dst) |
                         static_cast<uintptr_t>(row_bytes);
  if ((alignment & 15) == 0) {
    const int64_t num_vec = row_bytes / 16;
    const uint4* src4 = reinterpret_cast<const uint4*>(src);
    uint4* dst4 = reinterpret_cast<uint4*>(dst);
    for (int64_t j = lane_id; j < num_vec; j += kWarpSize) {
      __stcg(dst4 + j, __ldcg(src4 + j));
    }
    return;
  }

  if ((alignment & 3) == 0) {
    const int64_t num_words = row_bytes / 4;
    const unsigned int* src_words = reinterpret_cast<const unsigned int*>(src);
    unsigned int* dst_words = reinterpret_cast<unsigned int*>(dst);
    for (int64_t j = lane_id; j < num_words; j += kWarpSize) {
      __stcg(dst_words + j, __ldcg(src_words + j));
    }
    return;
  }

  for (int64_t j = lane_id; j < row_bytes; j += kWarpSize) {
    __stcg(dst + j, __ldcg(src + j));
  }
}

// Zero one row with a single warp (16B vectorized, L2-only stores), same
// addressing contract as copy_row_warp.
__device__ __forceinline__ void zero_row_warp(int lane_id, char* dst,
                                              int64_t row_bytes) {
  const auto alignment =
      reinterpret_cast<uintptr_t>(dst) | static_cast<uintptr_t>(row_bytes);
  if ((alignment & 15) == 0) {
    const int64_t num_vec = row_bytes / 16;
    uint64_t* dst8 = reinterpret_cast<uint64_t*>(dst);
    for (int64_t j = lane_id; j < num_vec; j += kWarpSize) {
      uint64_t* d = dst8 + j * 2;
      asm volatile("st.global.cg.v2.b64 [%0],{%1,%2};" ::"l"(d), "l"(0ULL),
                   "l"(0ULL)
                   : "memory");
    }
    return;
  }

  if ((alignment & 3) == 0) {
    const int64_t num_words = row_bytes / 4;
    unsigned int* dst_words = reinterpret_cast<unsigned int*>(dst);
    for (int64_t j = lane_id; j < num_words; j += kWarpSize) {
      __stcg(dst_words + j, 0u);
    }
    return;
  }

  for (int64_t j = lane_id; j < row_bytes; j += kWarpSize) {
    __stcg(dst + j, static_cast<char>(0));
  }
}

__device__ __forceinline__ char* cache_row_ptr(char* cache, int64_t row,
                                               int32_t block_size,
                                               int64_t block_stride,
                                               int64_t row_bytes) {
  return cache + (row / block_size) * block_stride +
         (row % block_size) * row_bytes;
}

// Load host row g into hot row dst. A g past the host pool has no source row,
// so dst is zeroed rather than left serving stale bytes.
__device__ __forceinline__ void load_hot_row_warp(
    int lane_id, const char* host_cache, char* hot_cache, int32_t g,
    int32_t dst, int64_t host_rows, int64_t hot_rows, int64_t row_bytes,
    int64_t hot_block_stride, int32_t hot_block_size) {
  if (g < 0 || dst < 0 || dst >= hot_rows) {
    return;
  }
  char* dst_row = cache_row_ptr(hot_cache, dst, hot_block_size,
                                hot_block_stride, row_bytes);
  if (g < host_rows) {
    copy_row_warp(lane_id, host_cache + static_cast<int64_t>(g) * row_bytes,
                  dst_row, row_bytes);
  } else {
    zero_row_warp(lane_id, dst_row, row_bytes);
  }
}

// In-place inclusive scan over s_data[offset, count) performed by warp 0,
// carrying `accumulator` across calls. Returns the running total.
__device__ __forceinline__ int warp_inclusive_scan(int32_t* s_data, int lane_id,
                                                   int offset, int count,
                                                   int accumulator) {
  int idx = lane_id + offset;
  int val = (idx < count) ? s_data[idx] : 0;
#pragma unroll
  for (int i = 1; i < 32; i *= 2) {
    int n = __shfl_up_sync(0xffffffff, val, i);
    if (lane_id >= i) val += n;
  }
  val += accumulator;
  if (idx < count) {
    s_data[idx] = val;
  }
  return __shfl_sync(0xffffffff, val, 31);
}

// Non-negative x only. Block sizes are powers of two in practice, and integer
// division would otherwise dominate the resolver's per-position instructions.
__device__ __forceinline__ int32_t block_div(int32_t x, int32_t block_size) {
  return (block_size & (block_size - 1)) == 0 ? x >> (__ffs(block_size) - 1)
                                              : x / block_size;
}

__device__ __forceinline__ int32_t block_mod(int32_t x, int32_t block_size) {
  return (block_size & (block_size - 1)) == 0 ? x & (block_size - 1)
                                              : x % block_size;
}

__device__ __forceinline__ int64_t
get_physical_hot_row(const int32_t* hot_block_table, int32_t row,
                     int64_t table_stride, int32_t block_size, int32_t slot) {
  const int32_t block =
      hot_block_table[static_cast<int64_t>(row) * table_stride +
                      block_div(slot, block_size)];
  return static_cast<int64_t>(block) * block_size + block_mod(slot, block_size);
}

__device__ __forceinline__ void store_hot_index(
    int32_t* hot_indices, int32_t* attention_indices, int32_t index,
    int32_t physical_row, int32_t hot_block_size,
    int64_t attention_block_stride) {
  hot_indices[index] = physical_row;
  if (attention_indices != nullptr) {
    attention_indices[index] =
        physical_row < 0
            ? -1
            : block_div(physical_row, hot_block_size) * attention_block_stride +
                  block_mod(physical_row, hot_block_size);
  }
}

// A union entry's value holds its first (row, top-k) position until phase 2
// or 3 resolves it to a hot slot tagged with how it was resolved.
constexpr int32_t kEntryHit = 1 << 30;
constexpr int32_t kEntryMiss = 1 << 29;
constexpr int32_t kEntryInvalid = 1 << 28;
constexpr int32_t kEntrySlotMask = 0xFFFF;
constexpr int kResidencyCounters = 5;
// Per-request table entries per referenced top-k position, within the
// device's shared-memory budget.
constexpr int kHashLoadInverse = 4;
// Top-k positions per thread the resolver loads before its request lookups.
constexpr int kPrefetchedTopK = 2;

// Translate a request-relative top-k position to its resident GPU row (-1 when
// the page is not resident) and returns its host row (-1 when not host-backed).
__device__ __forceinline__ int32_t translate_topk_entry(
    const int32_t token_index, const int32_t request_row,
    const int32_t state_row, const int32_t* __restrict__ source_block_table,
    const int32_t* __restrict__ resident_block_table, const int64_t host_rows,
    const int64_t source_bt_stride, const int32_t source_num_reqs,
    const int32_t source_num_blocks, const int32_t source_block_size,
    const int64_t resident_bt_stride, const int32_t resident_num_reqs,
    const int32_t resident_num_blocks, const int32_t resident_block_size,
    int32_t& resident_row) {
  int32_t g = token_index;
  resident_row = -1;
  if (source_block_table != nullptr) {
    const int32_t source_block =
        token_index >= 0 ? block_div(token_index, source_block_size) : -1;
    if (request_row >= 0 && request_row < source_num_reqs &&
        source_block >= 0 && source_block < source_num_blocks) {
      const int32_t physical_block =
          source_block_table[static_cast<int64_t>(request_row) *
                                 source_bt_stride +
                             source_block];
      g = physical_block > 0 ? physical_block * source_block_size +
                                   block_mod(token_index, source_block_size)
                             : -1;
    } else {
      g = -1;
    }
    if (resident_block_table != nullptr) {
      const int32_t resident_block =
          token_index >= 0 ? block_div(token_index, resident_block_size) : -1;
      if (state_row >= 0 && state_row < resident_num_reqs &&
          resident_block >= 0 && resident_block < resident_num_blocks) {
        const int32_t physical_block =
            resident_block_table[static_cast<int64_t>(state_row) *
                                     resident_bt_stride +
                                 resident_block];
        // Block 0 marks a page read from the host.
        if (physical_block > 0) {
          resident_row = physical_block * resident_block_size +
                         block_mod(token_index, resident_block_size);
        }
      }
    }
  }
  return g >= host_rows ? -1 : g;
}

// Phase 1 parks host rows in hot_indices as values below -1, distinct from
// resident rows (>= 0) and invalid positions (-1).
__device__ __forceinline__ int32_t encode_host_row(const int32_t g) {
  return -2 - g;
}

// Write the hot index of one reference to a resolved union entry and tally it.
__device__ __forceinline__ void write_entry_index(
    const int32_t entry, const int row, const int i, const int32_t top_k,
    int32_t* __restrict__ hot_indices, int32_t* __restrict__ attention_indices,
    const int64_t attention_row_stride,
    const int32_t* __restrict__ hot_block_table, const int request_row,
    const int64_t hot_table_stride, const int32_t hot_block_size,
    const int64_t attention_block_stride, const bool first_reference, int& hits,
    int& misses) {
  int32_t* row_out = hot_indices + static_cast<int64_t>(row) * top_k;
  int32_t* row_attention =
      attention_indices != nullptr
          ? attention_indices + static_cast<int64_t>(row) * attention_row_stride
          : nullptr;
  if (entry & kEntryInvalid) {
    store_hot_index(row_out, row_attention, i, -1, hot_block_size,
                    attention_block_stride);
    return;
  }
  store_hot_index(row_out, row_attention, i,
                  static_cast<int32_t>(get_physical_hot_row(
                      hot_block_table, request_row, hot_table_stride,
                      hot_block_size, entry & kEntrySlotMask)),
                  hot_block_size, attention_block_stride);
  // Only an entry's first reference loads it; later references reuse the
  // slot like a hit.
  if ((entry & kEntryMiss) && first_reference) {
    ++misses;
  } else {
    ++hits;
  }
}

// One block per request, launched per batch row. A request's rows (several
// with speculative decoding) are contiguous and share its hot-buffer state, so
// the block of its first row resolves the union of their host misses once and
// maps every row onto it; the other blocks exit. The union is bounded by the
// caller's max_union_rows (every decode query's top-k), which
// device_buffer_size covers; a larger union traps. Misses take eviction slots
// in (row, top-k) order of first reference, so the plan is deterministic.
//
// Shared memory layout (int32 region followed by int16 region):
//   s_hash_keys[hash_size]   open addressing: union of the rows' host ids
//   s_hash_vals[hash_size]   first position, then slot | kEntry* tag
//   s_chunk_off[nbc + 1]     prefix sums for hit, then miss, compaction
//   s_evict_off[nbc + 1]     prefix sums for evictable compaction
//   s_counters[5]            distinct hits, union size, per-entry misses,
//                            host positions (phase 1) then misses,
//                            per-entry hits
//   s_done[nbc]              hot slots holding a union row (phase 2), then
//                            positions phase 3 resolved, one word per chunk
//   s_lru_out[hot_size]      int16, compacted slots: [hits fwd | evict bwd]
// Valid global ids must be unique within each row. A nonzero kBlockSize fixes
// every block size at compile time.
template <int kBlockSize>
__global__ __launch_bounds__(1024) void hisparse_resolve_residency_kernel(
    const int32_t* __restrict__ hot_block_table,  // [max_rows, hot_blocks]
    const int32_t* __restrict__ global_indices,   // global or request-relative
    const int32_t* __restrict__ request_ids,      // [num_rows] or nullptr
    const int32_t* __restrict__ source_block_table,  // [num_reqs, max_blocks]
    const int32_t* __restrict__ resident_block_table,
    int32_t* __restrict__ valid_counts,               // [num_rows] or nullptr
    int32_t* __restrict__ swap_host_physical_rows,    // [num_rows, top_k]
    int32_t* __restrict__ swap_device_physical_rows,  // [num_rows, top_k]
    int32_t* __restrict__ swap_counts,                // [num_rows]
    int32_t* __restrict__ hot_indices,                // [num_rows, top_k]
    int32_t* __restrict__ attention_indices,          // [num_rows, top_k]
    int32_t* __restrict__ device_global_indices,  // [max_rows, region_stride]
    int16_t* __restrict__ lru_slots,              // [max_rows, hot_size]
    unsigned long long* __restrict__ stats,       // [2] hits,misses or nullptr
    const int32_t* __restrict__ request_state_indices,  // [num_requests] or
                                                        // nullptr
    const int32_t request_state_count, const int64_t host_rows,
    const int64_t hot_table_stride, const int32_t hot_block_size_arg,
    const int32_t top_k, const int32_t hot_size, const int32_t hash_size,
    const int32_t max_union_rows, const int64_t region_stride,
    const int64_t attention_block_stride, const int64_t source_bt_stride,
    const int32_t source_num_reqs, const int32_t source_num_blocks,
    const int32_t source_block_size_arg, const int64_t resident_bt_stride,
    const int32_t resident_num_reqs, const int32_t resident_num_blocks,
    const int32_t resident_block_size_arg, const int64_t input_row_stride,
    const int64_t attention_row_stride, const int64_t valid_count_stride,
    const int32_t* __restrict__ num_valid_rows) {  // [1] or nullptr
  const int32_t hot_block_size =
      kBlockSize > 0 ? kBlockSize : hot_block_size_arg;
  const int32_t source_block_size =
      kBlockSize > 0 ? kBlockSize : source_block_size_arg;
  const int32_t resident_block_size =
      kBlockSize > 0 ? kBlockSize : resident_block_size_arg;
  const int NUM_WARPS = blockDim.x / kWarpSize;
  const int num_buffer_chunks = (hot_size + kWarpSize - 1) / kWarpSize;

  const int tid = threadIdx.x;
  const int warp_id = tid / kWarpSize;
  const int lane_id = tid % kWarpSize;
  const unsigned int lanes_before = ((unsigned int)1 << lane_id) - 1;
  const int first_row = blockIdx.x;

  // Issued before the request lookups resolve so that an all-resident step
  // pays few dependent memory round trips.
  int32_t first_topk[kPrefetchedTopK];
#pragma unroll
  for (int k = 0; k < kPrefetchedTopK; ++k) {
    const int i = tid + k * blockDim.x;
    first_topk[k] = i < top_k ? global_indices[static_cast<int64_t>(first_row) *
                                                   input_row_stride +
                                               i]
                              : -1;
  }
  // FULL CUDA-graph padding rows past num_valid_rows belong to no request.
  const int valid_rows = num_valid_rows != nullptr
                             ? min(*num_valid_rows, static_cast<int>(gridDim.x))
                             : static_cast<int>(gridDim.x);
  const auto request_of = [&](const int row) -> int32_t {
    if (request_ids == nullptr) return row;
    const int32_t request = request_ids[row];
    return row < valid_rows ? request : -1;
  };
  const int request_row = request_of(first_row);
  const int state_row =
      request_state_indices != nullptr && request_row >= 0 &&
              request_row < request_state_count
          ? request_state_indices[request_row]
          : (request_state_indices == nullptr ? request_row : -1);
  // V2 publishes -1 for CUDA-graph padding rows. They share no request state,
  // so every block masks its own row.
  if (state_row < 0) {
    for (int i = tid; i < top_k; i += blockDim.x) {
      hot_indices[static_cast<int64_t>(first_row) * top_k + i] = -1;
      if (attention_indices != nullptr) {
        attention_indices[static_cast<int64_t>(first_row) *
                              attention_row_stride +
                          i] = -1;
      }
    }
    if (valid_counts != nullptr && tid == 0) {
      valid_counts[static_cast<int64_t>(first_row) * valid_count_stride] = 0;
    }
    if (swap_counts != nullptr && tid == 0) {
      swap_counts[first_row] = 0;
    }
    return;
  }
  // The first row of each contiguous run of a request's rows leads it.
  if (request_ids != nullptr && first_row > 0 &&
      request_of(first_row - 1) == request_row) {
    return;
  }
  int end_row = first_row + 1;
  if (request_ids != nullptr) {
    while (end_row < static_cast<int>(gridDim.x) &&
           request_of(end_row) == request_row) {
      ++end_row;
    }
  }

  int32_t* row_dgi =
      device_global_indices + static_cast<int64_t>(state_row) * region_stride;
  int16_t* row_lru = lru_slots + static_cast<int64_t>(state_row) * hot_size;

  extern __shared__ char smem_raw[];
  int32_t* s_hash_keys = reinterpret_cast<int32_t*>(smem_raw);
  int32_t* s_hash_vals = s_hash_keys + hash_size;
  int32_t* s_chunk_off = s_hash_vals + hash_size;
  int32_t* s_evict_off = s_chunk_off + (num_buffer_chunks + 1);
  int32_t* s_counters = s_evict_off + (num_buffer_chunks + 1);
  unsigned int* s_done =
      reinterpret_cast<unsigned int*>(s_counters + kResidencyCounters);
  int16_t* s_lru_out = reinterpret_cast<int16_t*>(s_done + num_buffer_chunks);

  for (int i = tid; i < num_buffer_chunks + 1; i += blockDim.x) {
    s_chunk_off[i] = 0;
    s_evict_off[i] = 0;
  }
  if (tid < kResidencyCounters) {
    s_counters[tid] = 0;
  }
  __syncthreads();

  // Phase 1: translate every row's request-relative positions in one pass,
  // resolve resident rows directly, and count the host-backed positions.
  // s_chunk_off holds per-row valid counts until phase 2.
  int32_t* s_row_valid = s_chunk_off;
  const int num_positions = (end_row - first_row) * top_k;
  const auto resolve_position = [&](const int position,
                                    const int32_t token_index) {
    const int row = first_row + position / top_k;
    const int i = position % top_k;
    int32_t* row_out = hot_indices + static_cast<int64_t>(row) * top_k;
    int32_t* row_attention =
        attention_indices != nullptr
            ? attention_indices +
                  static_cast<int64_t>(row) * attention_row_stride
            : nullptr;
    int32_t resident_row;
    const int32_t g = translate_topk_entry(
        token_index, request_row, state_row, source_block_table,
        resident_block_table, host_rows, source_bt_stride, source_num_reqs,
        source_num_blocks, source_block_size, resident_bt_stride,
        resident_num_reqs, resident_num_blocks, resident_block_size,
        resident_row);
    if (resident_row >= 0 || g >= 0)
      atomicAdd(&s_row_valid[row - first_row], 1);
    if (resident_row >= 0) {
      store_hot_index(row_out, row_attention, i, resident_row, hot_block_size,
                      attention_block_stride);
    } else if (g < 0) {
      store_hot_index(row_out, row_attention, i, -1, hot_block_size,
                      attention_block_stride);
    } else {
      // Stash the host row in its output slot; later phases overwrite it.
      row_out[i] = encode_host_row(g);
      atomicAdd(&s_counters[3], 1);
    }
  };
#pragma unroll
  for (int k = 0; k < kPrefetchedTopK; ++k) {
    const int position = tid + k * blockDim.x;
    if (position < num_positions) {
      resolve_position(position,
                       position < top_k
                           ? first_topk[k]
                           : global_indices[static_cast<int64_t>(
                                                first_row + position / top_k) *
                                                input_row_stride +
                                            position % top_k]);
    }
  }
  for (int position = tid + kPrefetchedTopK * blockDim.x;
       position < num_positions; position += blockDim.x) {
    resolve_position(
        position,
        global_indices[static_cast<int64_t>(first_row + position / top_k) *
                           input_row_stride +
                       position % top_k]);
  }
  __syncthreads();
  for (int row = first_row + tid; row < end_row; row += blockDim.x) {
    if (valid_counts != nullptr) {
      valid_counts[static_cast<int64_t>(row) * valid_count_stride] =
          s_row_valid[row - first_row];
    }
    s_row_valid[row - first_row] = 0;
  }
  // Fully resident rows need only request-relative page translation. Avoid
  // building the table or touching the hot LRU when no row can consult it.
  const int host_positions = s_counters[3];
  if (host_positions == 0) {
    for (int row = first_row + tid; row < end_row; row += blockDim.x) {
      if (swap_counts != nullptr) swap_counts[row] = 0;
    }
    return;
  }

  // Use a slice sized to this request's rows so single-row requests
  // initialize a small table. Legal unions always leave an empty slot.
  const int table_size =
      min(hash_size, kHashLoadInverse * (end_row - first_row) * top_k);
  for (int i = tid; i < table_size; i += blockDim.x) {
    s_hash_keys[i] = kHashEmpty;
    s_hash_vals[i] = INT32_MAX;
  }
  __syncthreads();

  // Phase 1b: collect the union of host rows.
  for (int position = tid; position < num_positions; position += blockDim.x) {
    const int32_t stashed =
        hot_indices[static_cast<int64_t>(first_row) * top_k + position];
    if (stashed > -2) continue;
    const int32_t g = encode_host_row(stashed);
    int h = hash_slot(g, table_size);
    bool inserted = false;
    for (int probe = 0; probe < table_size; ++probe) {
      const int32_t old = atomicCAS(&s_hash_keys[h], kHashEmpty, g);
      if (old == kHashEmpty) {
        atomicAdd(&s_counters[1], 1);
        inserted = true;
        break;
      }
      if (old == g) {
        inserted = true;
        break;
      }
      h = next_slot(h, table_size);
    }
    if (inserted) {
      atomicMin(&s_hash_vals[h], position);
    } else {
      // A full table: push the union count past the cap so the check
      // below traps.
      atomicAdd(&s_counters[1], max_union_rows + 1);
    }
  }
  __syncthreads();
  // Hash capacity can exceed the union bound; eviction slots cannot.
  if (s_counters[1] > max_union_rows) {
    if (tid == 0) {
      printf(
          "HiSparse residency: request %d resolves %d host rows, above the "
          "configured bound of %d\n",
          request_row, s_counters[1], max_union_rows);
    }
    __trap();
  }

  // Phase 2: scan hot slots in slot order so device_global_indices is read
  // coalesced, recording each hit's slot on its union entry and in s_done.
  constexpr int kSlotBatch = 4;
  for (int base = 0; base < hot_size; base += kSlotBatch * blockDim.x) {
    int32_t cached_g[kSlotBatch];
#pragma unroll
    for (int b = 0; b < kSlotBatch; ++b) {
      const int slot = base + b * blockDim.x + tid;
      cached_g[b] = slot < hot_size ? row_dgi[slot] : -1;
    }
#pragma unroll
    for (int b = 0; b < kSlotBatch; ++b) {
      const int slot = base + b * blockDim.x + tid;
      // Every lane makes its first probe, then the warp iterates together
      // until no lane is still probing, so the warp is converged at the
      // ballot. CUDA 12.8-13.2.1 ptxas can fail to reconverge a per-lane
      // probe loop before a ballot on sm_100.
      const int32_t g = cached_g[b];
      int h = hash_slot(g, table_size);
      int32_t k = s_hash_keys[h];
      bool is_hit = g >= 0 && k == g;
      bool probing = g >= 0 && !is_hit && k != kHashEmpty;
      while (__any_sync(0xFFFFFFFF, probing)) {
        if (probing) h = next_slot(h, table_size);
        k = probing ? s_hash_keys[h] : kHashEmpty;
        const bool found = probing && k == g;
        is_hit |= found;
        probing = probing && !found && k != kHashEmpty;
      }
      if (is_hit) s_hash_vals[h] = kEntryHit | slot;
      const unsigned int hit_bits = __ballot_sync(0xFFFFFFFF, is_hit);
      if (lane_id == 0 && slot < hot_size) {
        s_done[slot / kWarpSize] = hit_bits;
      }
    }
  }
  __syncthreads();

  // Walk hot slots in LRU order, classify hit / evictable, and compact them
  // (hits forward, evictables backward) into s_lru_out.
  const int iters_buffer = (num_buffer_chunks + NUM_WARPS - 1) / NUM_WARPS;
  int total_hit_count = 0;
  int total_evict_count = 0;
  int16_t next_lru = tid < hot_size ? row_lru[tid] : int16_t(-1);
  for (int iter = 0; iter < iters_buffer; iter++) {
    const int chunk_idx = warp_id + iter * NUM_WARPS;
    const bool has_valid_chunk = chunk_idx < num_buffer_chunks;

    const int pos = chunk_idx * kWarpSize + lane_id;
    const bool has_valid_pos = has_valid_chunk && (pos < hot_size);
    const int16_t slot = has_valid_pos ? next_lru : int16_t(-1);
    const int next_pos = pos + NUM_WARPS * kWarpSize;
    next_lru = next_pos < hot_size ? row_lru[next_pos] : int16_t(-1);
    // Corruption tripwire: lru is long-lived device state; an out-of-range
    // slot is treated as no-hit so it degrades to a re-miss (phase 3 bounds
    // the write side).
    const bool is_hit = slot >= 0 && slot < hot_size &&
                        (s_done[slot / kWarpSize] >> (slot % kWarpSize)) & 1u;
    const bool is_evictable = has_valid_pos && !is_hit;

    int local_hit_off = 0;
    int local_evict_off = 0;
    if (has_valid_chunk) {
      const unsigned int hit_mask = __ballot_sync(0xFFFFFFFF, is_hit);
      const unsigned int evict_mask = __ballot_sync(0xFFFFFFFF, is_evictable);
      local_hit_off = __popc(hit_mask & lanes_before);
      local_evict_off = __popc(evict_mask & lanes_before);
      if (lane_id == 0) {
        s_chunk_off[chunk_idx + 1] = __popc(hit_mask);
        s_evict_off[chunk_idx + 1] = __popc(evict_mask);
      }
    }
    __syncthreads();

    if (warp_id == 0) {
      total_hit_count =
          warp_inclusive_scan(s_chunk_off, lane_id, chunk_idx + 1,
                              num_buffer_chunks + 1, total_hit_count);
      total_evict_count =
          warp_inclusive_scan(s_evict_off, lane_id, chunk_idx + 1,
                              num_buffer_chunks + 1, total_evict_count);
      if (tid == 0) {
        s_counters[0] = total_hit_count;
      }
    }
    __syncthreads();

    if (is_hit) {
      const int off = s_chunk_off[chunk_idx] + local_hit_off;
      s_lru_out[off] = slot;
    }
    if (is_evictable) {
      const int off = s_evict_off[chunk_idx] + local_evict_off;
      s_lru_out[hot_size - 1 - off] = slot;
    }
  }
  __syncthreads();

  for (int i = tid; i < num_buffer_chunks + 1; i += blockDim.x) {
    s_chunk_off[i] = 0;
  }
  __syncthreads();

  // Phase 3: walk the rows' positions in (row, top-k) order; the first
  // reference to a union entry no slot holds is a miss. Assign misses
  // eviction slots (oldest first) and record the new ownership in
  // device_global_indices. Swaps fill the rows' swap segments in order; the
  // union never exceeds their combined capacity, and position chunks never
  // exceed buffer chunks because hot_size covers every row's top-k.
  const int num_position_chunks = (num_positions + kWarpSize - 1) / kWarpSize;
  const int iters_position = (num_position_chunks + NUM_WARPS - 1) / NUM_WARPS;
  int miss_running_total = 0;
  int entry_hits = 0;
  int entry_misses = 0;
  for (int iter = 0; iter < iters_position; iter++) {
    const int chunk_idx = warp_id + iter * NUM_WARPS;
    const bool has_valid_chunk = chunk_idx < num_position_chunks;

    const int position = chunk_idx * kWarpSize + lane_id;
    int32_t g = -1;
    int h = -1;
    int32_t entry = 0;
    bool is_miss = false;
    if (has_valid_chunk && position < num_positions) {
      const int32_t stashed =
          hot_indices[static_cast<int64_t>(first_row) * top_k + position];
      if (stashed < -1) {
        g = encode_host_row(stashed);
        h = hash_slot(g, table_size);
        while (s_hash_keys[h] != g) {
          h = next_slot(h, table_size);
        }
        entry = s_hash_vals[h];
        is_miss = entry == position;
      }
    }

    int local_miss_off = 0;
    if (has_valid_chunk) {
      const unsigned int miss_mask_bits = __ballot_sync(0xFFFFFFFF, is_miss);
      local_miss_off = __popc(miss_mask_bits & lanes_before);
      if (lane_id == 0) {
        s_chunk_off[chunk_idx + 1] = __popc(miss_mask_bits);
      }
    }
    __syncthreads();

    if (warp_id == 0) {
      miss_running_total =
          warp_inclusive_scan(s_chunk_off, lane_id, chunk_idx + 1,
                              num_position_chunks + 1, miss_running_total);
      if (tid == 0) {
        s_counters[3] = miss_running_total;
      }
    }
    __syncthreads();

    if (is_miss) {
      const int m = s_chunk_off[chunk_idx] + local_miss_off;
      const int16_t evict_slot = s_lru_out[hot_size - 1 - m];
      const int64_t compact_index = static_cast<int64_t>(first_row) * top_k + m;
      if (evict_slot < 0 || evict_slot >= region_stride) {
        // Corruption tripwire: an out-of-range slot (corrupted lru state,
        // see phase 2) must not become a hot-cache/dgi write. Resolve the
        // entry as invalid (-1, masked by attention); it re-misses on a later
        // step, and its copy is skipped.
        s_hash_vals[h] = kEntryInvalid;
        if (swap_host_physical_rows != nullptr) {
          swap_host_physical_rows[compact_index] = g;
          swap_device_physical_rows[compact_index] = -1;
        }
      } else {
        s_hash_vals[h] = kEntryMiss | evict_slot;
        if (swap_host_physical_rows != nullptr) {
          swap_host_physical_rows[compact_index] = g;
          swap_device_physical_rows[compact_index] =
              static_cast<int32_t>(get_physical_hot_row(
                  hot_block_table, request_row, hot_table_stride,
                  hot_block_size, evict_slot));
        }
        row_dgi[evict_slot] = g;
      }
      entry = s_hash_vals[h];
    }

    // Hits, first references and references to entries resolved in an
    // earlier chunk write their hot index now; later references to an entry
    // resolved in this same chunk pass (only across rows) are left to phase 4.
    const bool resolved =
        h >= 0 && (entry & (kEntryHit | kEntryMiss | kEntryInvalid));
    if (resolved) {
      write_entry_index(
          entry, first_row + position / top_k, position % top_k, top_k,
          hot_indices, attention_indices, attention_row_stride, hot_block_table,
          request_row, hot_table_stride, hot_block_size, attention_block_stride,
          is_miss, entry_hits, entry_misses);
    }
    if (has_valid_chunk) {
      const unsigned int done_bits = __ballot_sync(0xFFFFFFFF, resolved);
      if (lane_id == 0) {
        s_done[chunk_idx] = done_bits;
      }
    }
  }
  __syncthreads();

  const int total_hits = s_counters[0];
  const int total_misses = s_counters[3];
  if (swap_counts != nullptr) {
    for (int row = first_row + tid; row < end_row; row += blockDim.x) {
      const int remaining = total_misses - (row - first_row) * top_k;
      swap_counts[row] = max(0, min(top_k, remaining));
    }
  }

  // Phase 4: references phase 3 left unresolved (later references across rows
  // to entries loaded in the same chunk pass) map onto the union's slots.
  // Single-row requests resolve everything in phase 3.
  if (end_row - first_row > 1) {
    for (int position = tid; position < num_positions; position += blockDim.x) {
      if (s_done[position / kWarpSize] & (1u << (position % kWarpSize))) {
        continue;
      }
      const int row = first_row + position / top_k;
      const int32_t stashed =
          hot_indices[static_cast<int64_t>(first_row) * top_k + position];
      if (stashed > -2) continue;
      const int32_t g = encode_host_row(stashed);
      int h = hash_slot(g, table_size);
      while (s_hash_keys[h] != g) {
        h = next_slot(h, table_size);
      }
      write_entry_index(s_hash_vals[h], row, position % top_k, top_k,
                        hot_indices, attention_indices, attention_row_stride,
                        hot_block_table, request_row, hot_table_stride,
                        hot_block_size, attention_block_stride, false,
                        entry_hits, entry_misses);
    }
  }
  if (stats != nullptr) {
    atomicAdd(&s_counters[4], entry_hits);
    atomicAdd(&s_counters[2], entry_misses);
    __syncthreads();
    if (tid == 0) {
      atomicAdd(&stats[0], static_cast<unsigned long long>(s_counters[4]));
      atomicAdd(&stats[1], static_cast<unsigned long long>(s_counters[2]));
    }
  }

  // Phase 5: write back the LRU order: stale evictables at the front,
  // freshly loaded misses next, then hits at MRU.
  const int total_evictable = hot_size - total_hits;
  const int remaining_evictable = total_evictable - total_misses;
  for (int i = tid; i < hot_size; i += blockDim.x) {
    if (i < remaining_evictable) {
      row_lru[i] = s_lru_out[hot_size - 1 - total_misses - i];
    } else if (i < remaining_evictable + total_misses) {
      row_lru[i] = s_lru_out[hot_size - 1 - (i - remaining_evictable)];
    } else {
      row_lru[i] = s_lru_out[i - remaining_evictable - total_misses];
    }
  }
}

// Prefill staging: copy the planned host rows (miss_mask != 0) into the
// staged cache. Fixed shape (num_rows x top_k), so it is CUDA-graph-capture
// safe.
__global__ void hisparse_gather_plan_kernel(
    const char* __restrict__ host_cache,         // [host_rows, row_bytes]
    char* __restrict__ hot_cache,                // [hot_rows, row_bytes]
    const int32_t* __restrict__ global_indices,  // [num_rows, top_k]
    const int32_t* __restrict__ hot_indices,  // [num_rows, top_k] abs hot rows
    const int32_t* __restrict__ miss_mask,    // [num_rows, top_k]
    const int64_t host_rows, const int64_t hot_rows, const int64_t row_bytes,
    const int64_t hot_block_stride, const int32_t hot_block_size,
    const int32_t top_k) {
  const int NUM_WARPS = blockDim.x / kWarpSize;
  // Columns are interleaved across gridDim.y blocks per row so the staging
  // plan's single row still fills the device with outstanding host reads.
  const int row = blockIdx.x;
  const int warp_id = threadIdx.x / kWarpSize;
  const int lane_id = threadIdx.x % kWarpSize;
  const int col_start = blockIdx.y * NUM_WARPS + warp_id;
  const int col_stride = gridDim.y * NUM_WARPS;
  const int64_t base = static_cast<int64_t>(row) * top_k;
  for (int col = col_start; col < top_k; col += col_stride) {
    if (miss_mask[base + col] == 0) {
      continue;
    }
    load_hot_row_warp(lane_id, host_cache, hot_cache,
                      global_indices[base + col], hot_indices[base + col],
                      host_rows, hot_rows, row_bytes, hot_block_stride,
                      hot_block_size);
  }
}

// Copy the compact swap rows produced by the residency resolver.
__global__ void hisparse_gather_compact_kernel(
    const char* __restrict__ host_cache, char* __restrict__ hot_cache,
    const int32_t* __restrict__ miss_global_indices,
    const int32_t* __restrict__ miss_hot_indices,
    const int32_t* __restrict__ miss_counts, const int64_t host_rows,
    const int64_t hot_rows, const int64_t row_bytes,
    const int64_t hot_block_stride, const int32_t hot_block_size,
    const int32_t top_k, const int32_t num_rows) {
  const int NUM_WARPS = blockDim.x / kWarpSize;
  const int warp_id = threadIdx.x / kWarpSize;
  const int lane_id = threadIdx.x % kWarpSize;
  const int col_start = blockIdx.y * NUM_WARPS + warp_id;
  const int col_stride = gridDim.y * NUM_WARPS;
  for (int row = blockIdx.x; row < num_rows; row += gridDim.x) {
    const int miss_count = min(max(miss_counts[row], 0), top_k);
    const int64_t base = static_cast<int64_t>(row) * top_k;
    for (int col = col_start; col < miss_count; col += col_stride) {
      load_hot_row_warp(lane_id, host_cache, hot_cache,
                        miss_global_indices[base + col],
                        miss_hot_indices[base + col], host_rows, hot_rows,
                        row_bytes, hot_block_stride, hot_block_size);
    }
  }
}

// One block per (written token, index group): drop the group's hot copy of
// the token's rewritten host slot.
__global__ void hisparse_invalidate_written_slots_kernel(
    int32_t* const* __restrict__ device_global_indices,  // [num_groups]
    const int32_t* __restrict__ request_state_indices,
    const int32_t* __restrict__ req_id_per_token,
    const int64_t* __restrict__ written_slots, const int64_t num_request_ids,
    const int64_t num_state_rows, const int64_t region_stride) {
  const int64_t token_idx = blockIdx.x;
  const int32_t req_idx = req_id_per_token[token_idx];
  if (req_idx < 0 || req_idx >= num_request_ids) {
    return;
  }
  const int32_t state_idx = request_state_indices[req_idx];
  const int64_t written_slot = written_slots[token_idx];
  if (state_idx < 0 || state_idx >= num_state_rows || written_slot < 0 ||
      written_slot > INT32_MAX) {
    return;
  }
  const int32_t slot = static_cast<int32_t>(written_slot);
  int32_t* row = device_global_indices[blockIdx.y] + state_idx * region_stride;
  if (region_stride % 4 == 0 && (reinterpret_cast<uintptr_t>(row) & 15) == 0) {
    const int4* row4 = reinterpret_cast<int4*>(row);
    for (int64_t offset = threadIdx.x; offset < region_stride / 4;
         offset += blockDim.x) {
      const int4 v = row4[offset];
      if (v.x == slot) row[4 * offset] = -1;
      if (v.y == slot) row[4 * offset + 1] = -1;
      if (v.z == slot) row[4 * offset + 2] = -1;
      if (v.w == slot) row[4 * offset + 3] = -1;
    }
    return;
  }
  for (int64_t offset = threadIdx.x; offset < region_stride;
       offset += blockDim.x) {
    if (row[offset] == slot) {
      row[offset] = -1;
    }
  }
}

int64_t check_2d_rows(const torch::stable::Tensor& t, const char* name,
                      int64_t row_bytes) {
  STD_TORCH_CHECK(t.dim() == 2, name, " must be 2D");
  STD_TORCH_CHECK(t.is_contiguous(), name, " must be contiguous");
  STD_TORCH_CHECK(t.size(1) * t.element_size() == row_bytes, name,
                  " row width mismatch");
  return t.size(0);
}

}  // namespace

void hisparse_invalidate_written_slots(
    torch::stable::Tensor const& device_global_indices_ptrs,
    torch::stable::Tensor const& request_state_indices,
    torch::stable::Tensor const& req_id_per_token,
    torch::stable::Tensor const& written_slots, int64_t num_state_rows,
    int64_t region_stride) {
  STD_TORCH_CHECK(device_global_indices_ptrs.is_cuda() &&
                      request_state_indices.is_cuda() &&
                      req_id_per_token.is_cuda() && written_slots.is_cuda(),
                  "HiSparse invalidation tensors must be on CUDA");
  STD_TORCH_CHECK(
      device_global_indices_ptrs.scalar_type() ==
              torch::headeronly::ScalarType::Long &&
          device_global_indices_ptrs.dim() == 1 &&
          device_global_indices_ptrs.is_contiguous(),
      "device_global_indices_ptrs must be a contiguous 1D int64 CUDA tensor "
      "of [max_num_reqs, region_stride] int32 table addresses");
  STD_TORCH_CHECK(
      request_state_indices.scalar_type() ==
              torch::headeronly::ScalarType::Int &&
          request_state_indices.dim() == 1 &&
          request_state_indices.is_contiguous(),
      "request_state_indices must be a contiguous 1D int32 CUDA tensor");
  STD_TORCH_CHECK(
      req_id_per_token.scalar_type() == torch::headeronly::ScalarType::Int &&
          req_id_per_token.dim() == 1 && req_id_per_token.is_contiguous(),
      "req_id_per_token must be a contiguous 1D int32 CUDA tensor");
  STD_TORCH_CHECK(
      written_slots.scalar_type() == torch::headeronly::ScalarType::Long &&
          written_slots.dim() == 1 && written_slots.is_contiguous(),
      "written_slots must be a contiguous 1D int64 CUDA tensor");
  STD_TORCH_CHECK(req_id_per_token.numel() == written_slots.numel(),
                  "req_id_per_token and written_slots must have equal length");
  const int device_index = device_global_indices_ptrs.get_device_index();
  STD_TORCH_CHECK(
      request_state_indices.get_device_index() == device_index &&
          req_id_per_token.get_device_index() == device_index &&
          written_slots.get_device_index() == device_index,
      "HiSparse invalidation tensors must be on the same CUDA device");

  const int64_t num_tokens = written_slots.numel();
  const int64_t num_groups = device_global_indices_ptrs.numel();
  if (num_tokens == 0 || num_groups == 0 || num_state_rows == 0 ||
      region_stride == 0) {
    return;
  }
  STD_TORCH_CHECK(num_tokens <= INT32_MAX && num_groups <= 65535,
                  "HiSparse invalidation grid exceeds CUDA limits");

  constexpr int kBlockSize = 256;
  const torch::stable::accelerator::DeviceGuard device_guard(device_index);
  const cudaStream_t stream = get_current_cuda_stream();
  const dim3 grid(static_cast<unsigned int>(num_tokens),
                  static_cast<unsigned int>(num_groups));
  hisparse_invalidate_written_slots_kernel<<<grid, kBlockSize, 0, stream>>>(
      static_cast<int32_t* const*>(device_global_indices_ptrs.const_data_ptr()),
      request_state_indices.const_data_ptr<int32_t>(),
      req_id_per_token.const_data_ptr<int32_t>(),
      written_slots.const_data_ptr<int64_t>(), request_state_indices.numel(),
      num_state_rows, region_stride);
  const cudaError_t launch_error = cudaGetLastError();
  STD_TORCH_CHECK(launch_error == cudaSuccess,
                  "HiSparse invalidation kernel launch failed: ",
                  cudaGetErrorString(launch_error));
}

void hisparse_resolve_residency(
    torch::stable::Tensor const& host_cache, torch::stable::Tensor& hot_cache,
    torch::stable::Tensor const& hot_block_table,
    torch::stable::Tensor const& global_indices,
    torch::stable::Tensor& hot_indices,
    torch::stable::Tensor& device_global_indices,
    torch::stable::Tensor& lru_slots,
    std::optional<torch::stable::Tensor> const& request_state_indices,
    int64_t region_stride, int64_t max_union_rows,
    std::optional<torch::stable::Tensor> const& stats,
    std::optional<torch::stable::Tensor> const& attention_indices,
    int64_t attention_block_stride,
    std::optional<torch::stable::Tensor> const& request_ids,
    std::optional<torch::stable::Tensor> const& source_block_table,
    int64_t source_block_size,
    std::optional<torch::stable::Tensor> const& valid_counts,
    std::optional<torch::stable::Tensor> const& swap_host_physical_rows,
    std::optional<torch::stable::Tensor> const& swap_device_physical_rows,
    std::optional<torch::stable::Tensor> const& swap_counts,
    std::optional<torch::stable::Tensor> const& resident_block_table,
    int64_t resident_block_size,
    std::optional<torch::stable::Tensor> const& num_valid_rows) {
  STD_TORCH_CHECK(host_cache.device().is_cpu(),
                  "host_cache must be CPU memory");
  STD_TORCH_CHECK(hot_cache.is_cuda(), "hot_cache must be on CUDA");
  STD_TORCH_CHECK(
      hot_block_table.is_cuda() &&
          hot_block_table.scalar_type() == torch::headeronly::ScalarType::Int &&
          hot_block_table.dim() == 2,
      "hot_block_table must be a 2D int32 CUDA tensor");
  STD_TORCH_CHECK(global_indices.is_cuda() && hot_indices.is_cuda() &&
                      device_global_indices.is_cuda() && lru_slots.is_cuda(),
                  "index tensors must be on CUDA");
  STD_TORCH_CHECK(
      global_indices.scalar_type() == torch::headeronly::ScalarType::Int &&
          hot_indices.scalar_type() == torch::headeronly::ScalarType::Int,
      "global_indices/hot_indices must be int32");
  STD_TORCH_CHECK(
      device_global_indices.scalar_type() == torch::headeronly::ScalarType::Int,
      "device_global_indices must be int32");
  STD_TORCH_CHECK(
      lru_slots.scalar_type() == torch::headeronly::ScalarType::Short,
      "lru_slots must be int16");
  STD_TORCH_CHECK(global_indices.dim() == 2 && global_indices.stride(1) == 1,
                  "global_indices must be row-major 2D");
  const int64_t num_rows = global_indices.size(0);
  STD_TORCH_CHECK(num_rows >= 0 && num_rows <= INT32_MAX,
                  "num_rows must fit the CUDA grid");
  STD_TORCH_CHECK(hot_indices.size(0) == num_rows &&
                      hot_indices.size(1) == global_indices.size(1) &&
                      hot_indices.is_contiguous(),
                  "hot_indices must have one contiguous row per launch row");
  STD_TORCH_CHECK(
      device_global_indices.dim() == 2 && device_global_indices.is_contiguous(),
      "device_global_indices must be contiguous 2D");
  STD_TORCH_CHECK(
      lru_slots.dim() == 2 &&
          lru_slots.size(0) == device_global_indices.size(0) &&
          lru_slots.is_contiguous(),
      "lru_slots must be contiguous with one row per request state");
  STD_TORCH_CHECK(hot_cache.dim() == 3,
                  "hot_cache must be [num_blocks, block_size, row_width]");
  const int64_t row_bytes = hot_cache.size(-1) * hot_cache.element_size();
  STD_TORCH_CHECK(row_bytes % 16 == 0, "KV rows must be 16-byte aligned");
  STD_TORCH_CHECK(hot_cache.stride(1) * hot_cache.element_size() == row_bytes,
                  "hot-cache rows must be contiguous");
  const int64_t hot_block_size = hot_cache.size(1);
  const int64_t hot_rows = hot_cache.size(0) * hot_block_size;
  const int64_t hot_block_stride =
      hot_cache.stride(0) * hot_cache.element_size();
  const int64_t host_rows = check_2d_rows(host_cache, "host_cache", row_bytes);
  const auto launch_rows = static_cast<int32_t>(num_rows);
  const auto top_k = static_cast<int32_t>(global_indices.size(1));
  const auto hot_size = static_cast<int32_t>(lru_slots.size(1));
  STD_TORCH_CHECK(hot_size >= top_k, "hot buffer size must be >= top_k");
  STD_TORCH_CHECK(hot_size <= 32768, "hot buffer size must fit int16 slots");
  STD_TORCH_CHECK(region_stride == hot_size,
                  "region_stride must match the LRU size");
  STD_TORCH_CHECK(device_global_indices.size(1) == region_stride,
                  "device_global_indices must cover the full hot region");
  STD_TORCH_CHECK(hot_block_table.size(1) >=
                      (region_stride + hot_block_size - 1) / hot_block_size,
                  "hot_block_table has too few columns");
  STD_TORCH_CHECK(hot_rows < INT32_MAX, "hot indices must fit int32");

  const int32_t* request_ids_ptr = nullptr;
  const int32_t* source_block_table_ptr = nullptr;
  int64_t source_bt_stride = 0;
  int32_t source_num_reqs = 0;
  int32_t source_num_blocks = 0;
  STD_TORCH_CHECK(
      request_ids.has_value() == source_block_table.has_value(),
      "request_ids and source_block_table must be provided together");
  if (source_block_table.has_value()) {
    auto const& req = request_ids.value();
    auto const& table = source_block_table.value();
    STD_TORCH_CHECK(
        req.is_cuda() &&
            req.scalar_type() == torch::headeronly::ScalarType::Int &&
            req.numel() >= launch_rows && req.is_contiguous(),
        "request_ids must be contiguous int32 on CUDA with one entry per row");
    STD_TORCH_CHECK(
        table.is_cuda() &&
            table.scalar_type() == torch::headeronly::ScalarType::Int &&
            table.dim() == 2 && table.stride(1) == 1,
        "source_block_table must be a row-major 2D int32 CUDA tensor");
    STD_TORCH_CHECK(source_block_size > 0,
                    "source_block_size must be positive");
    request_ids_ptr = req.const_data_ptr<int32_t>();
    source_block_table_ptr = table.const_data_ptr<int32_t>();
    source_bt_stride = table.stride(0);
    source_num_reqs = static_cast<int32_t>(table.size(0));
    source_num_blocks = static_cast<int32_t>(table.size(1));
  }
  const int32_t* num_valid_rows_ptr = nullptr;
  if (num_valid_rows.has_value()) {
    auto const& valid_rows = num_valid_rows.value();
    STD_TORCH_CHECK(request_ids.has_value(),
                    "num_valid_rows requires request_ids");
    STD_TORCH_CHECK(
        valid_rows.is_cuda() &&
            valid_rows.scalar_type() == torch::headeronly::ScalarType::Int &&
            valid_rows.numel() == 1,
        "num_valid_rows must be a one-element int32 CUDA tensor");
    num_valid_rows_ptr = valid_rows.const_data_ptr<int32_t>();
  }
  const int32_t required_hot_rows =
      request_ids_ptr != nullptr ? source_num_reqs : launch_rows;
  STD_TORCH_CHECK(hot_block_table.size(0) >= required_hot_rows,
                  "hot_block_table has too few rows");

  const int32_t* resident_block_table_ptr = nullptr;
  int64_t resident_bt_stride = 0;
  int32_t resident_num_reqs = 0;
  int32_t resident_num_blocks = 0;
  if (resident_block_table.has_value()) {
    auto const& table = resident_block_table.value();
    STD_TORCH_CHECK(
        source_block_table.has_value() && request_ids.has_value(),
        "resident lookup requires request_ids and source_block_table");
    STD_TORCH_CHECK(
        table.is_cuda() &&
            table.scalar_type() == torch::headeronly::ScalarType::Int &&
            table.dim() == 2 && table.stride(1) == 1,
        "resident_block_table must be a row-major 2D int32 CUDA tensor");
    STD_TORCH_CHECK(resident_block_size == hot_block_size,
                    "resident and hot block sizes must match");
    resident_block_table_ptr = table.const_data_ptr<int32_t>();
    resident_bt_stride = table.stride(0);
    resident_num_reqs = static_cast<int32_t>(table.size(0));
    resident_num_blocks = static_cast<int32_t>(table.size(1));
  }

  int32_t* valid_counts_ptr = nullptr;
  if (valid_counts.has_value()) {
    auto const& counts = valid_counts.value();
    STD_TORCH_CHECK(
        counts.is_cuda() &&
            counts.scalar_type() == torch::headeronly::ScalarType::Int &&
            counts.dim() == 1 && counts.size(0) == launch_rows,
        "valid_counts must be int32 on CUDA with one entry per row");
    valid_counts_ptr = counts.mutable_data_ptr<int32_t>();
  }

  int32_t* swap_host_physical_rows_ptr = nullptr;
  int32_t* swap_device_physical_rows_ptr = nullptr;
  int32_t* swap_counts_ptr = nullptr;
  const bool has_compact_swaps = swap_host_physical_rows.has_value();
  STD_TORCH_CHECK(has_compact_swaps == swap_device_physical_rows.has_value() &&
                      has_compact_swaps == swap_counts.has_value(),
                  "compact swap tensors must be provided together");
  if (has_compact_swaps) {
    auto const& globals = swap_host_physical_rows.value();
    auto const& hots = swap_device_physical_rows.value();
    auto const& counts = swap_counts.value();
    STD_TORCH_CHECK(
        globals.is_cuda() && hots.is_cuda() && counts.is_cuda() &&
            globals.scalar_type() == torch::headeronly::ScalarType::Int &&
            hots.scalar_type() == torch::headeronly::ScalarType::Int &&
            counts.scalar_type() == torch::headeronly::ScalarType::Int &&
            globals.dim() == 2 && hots.dim() == 2 &&
            globals.size(0) == launch_rows &&
            globals.size(1) == global_indices.size(1) &&
            hots.size(0) == launch_rows &&
            hots.size(1) == global_indices.size(1) &&
            counts.numel() >= launch_rows && globals.is_contiguous() &&
            hots.is_contiguous() && counts.is_contiguous(),
        "compact swaps must be contiguous int32 matching indices");
    swap_host_physical_rows_ptr = globals.mutable_data_ptr<int32_t>();
    swap_device_physical_rows_ptr = hots.mutable_data_ptr<int32_t>();
    swap_counts_ptr = counts.mutable_data_ptr<int32_t>();
  }

  const int32_t* request_state_ptr = nullptr;
  int32_t request_state_count = 0;
  if (request_state_indices.has_value()) {
    auto const& state_indices = request_state_indices.value();
    STD_TORCH_CHECK(
        state_indices.is_cuda() &&
            state_indices.scalar_type() == torch::headeronly::ScalarType::Int &&
            state_indices.dim() == 1 && state_indices.is_contiguous() &&
            state_indices.numel() <= INT32_MAX,
        "request_state_indices must be contiguous 1D int32 on CUDA");
    request_state_ptr = state_indices.const_data_ptr<int32_t>();
    request_state_count = static_cast<int32_t>(state_indices.numel());
  } else {
    STD_TORCH_CHECK(device_global_indices.size(0) >= launch_rows,
                    "device_global_indices has too few rows");
  }

  unsigned long long* stats_ptr = nullptr;
  if (stats.has_value()) {
    auto const& st = stats.value();
    STD_TORCH_CHECK(
        st.is_cuda() && st.is_contiguous() && st.dim() == 1 &&
            st.scalar_type() == torch::headeronly::ScalarType::UInt64 &&
            st.numel() == 2,
        "stats must be a contiguous two-element uint64 CUDA tensor");
    stats_ptr = static_cast<unsigned long long*>(st.mutable_data_ptr());
  }

  int32_t* attention_indices_ptr = nullptr;
  if (attention_indices.has_value()) {
    auto const& indices = attention_indices.value();
    STD_TORCH_CHECK(
        indices.is_cuda() &&
            indices.scalar_type() == torch::headeronly::ScalarType::Int &&
            indices.dim() == 2 && indices.size(0) == launch_rows &&
            indices.stride(1) == 1 && indices.size(1) == global_indices.size(1),
        "attention_indices must be row-major int32 matching global_indices");
    STD_TORCH_CHECK(attention_block_stride >= hot_block_size,
                    "attention block stride must cover one hot block");
    attention_indices_ptr = indices.mutable_data_ptr<int32_t>();
  }

  if (launch_rows == 0 || top_k == 0) {
    return;
  }

  constexpr int kBlockSize = 1024;
  STD_TORCH_CHECK(max_union_rows > 0 && max_union_rows <= hot_size,
                  "max_union_rows must be in [1, hot_size], got ",
                  max_union_rows);
  const int num_buffer_chunks = (hot_size + kWarpSize - 1) / kWarpSize;
  const size_t fixed_smem_bytes =
      sizeof(int32_t) * (3 * num_buffer_chunks + 2 + kResidencyCounters) +
      sizeof(int16_t) * hot_size;
  const size_t min_smem_bytes =
      fixed_smem_bytes + 2 * sizeof(int32_t) * (max_union_rows + 1);

  const torch::stable::accelerator::DeviceGuard device_guard(
      hot_cache.get_device_index());
  int max_smem_bytes = 0;
  STD_TORCH_CHECK(cudaDeviceGetAttribute(
                      &max_smem_bytes, cudaDevAttrMaxSharedMemoryPerBlockOptin,
                      hot_cache.get_device_index()) == cudaSuccess,
                  "failed to query shared memory per block");
  STD_TORCH_CHECK(min_smem_bytes <= static_cast<size_t>(max_smem_bytes),
                  "HiSparse device_buffer_size=", hot_size, " needs ",
                  min_smem_bytes,
                  " bytes of shared memory to resolve residency, "
                  "but the device allows ",
                  max_smem_bytes,
                  "; lower device_buffer_size or the number of speculative "
                  "tokens.");
  // Keep the table sparse when possible without rejecting configurations
  // that fit the minimum table with one spare entry above the union bound.
  const int hash_size =
      std::min(kHashLoadInverse * static_cast<int>(max_union_rows) + 1,
               static_cast<int>((max_smem_bytes - fixed_smem_bytes) /
                                (2 * sizeof(int32_t))));
  const size_t smem_bytes = fixed_smem_bytes + 2 * sizeof(int32_t) * hash_size;
  const cudaStream_t stream = get_current_cuda_stream();
  const int64_t attention_row_stride =
      attention_indices.has_value() ? attention_indices.value().stride(0) : 0;
  const int64_t valid_count_stride =
      valid_counts.has_value() ? valid_counts.value().stride(0) : 0;
  // Block arithmetic dominates the all-resident path; specialize the
  // ubiquitous 64-row block.
  constexpr int kFixedBlockSize = 64;
  const bool fixed_block_size = hot_block_size == kFixedBlockSize &&
                                (!source_block_table.has_value() ||
                                 source_block_size == kFixedBlockSize) &&
                                (!resident_block_table.has_value() ||
                                 resident_block_size == kFixedBlockSize);
  auto kernel = fixed_block_size
                    ? hisparse_resolve_residency_kernel<kFixedBlockSize>
                    : hisparse_resolve_residency_kernel<0>;
  if (smem_bytes > 48 * 1024) {
    static std::vector<size_t> configured_smem_bytes[2];
    std::vector<size_t>& configured = configured_smem_bytes[fixed_block_size];
    const size_t device_index = hot_cache.get_device_index();
    if (configured.size() <= device_index) {
      configured.resize(device_index + 1, 0);
    }
    if (configured[device_index] < smem_bytes) {
      const cudaError_t attribute_error = cudaFuncSetAttribute(
          kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, smem_bytes);
      STD_TORCH_CHECK(attribute_error == cudaSuccess,
                      "failed to configure HiSparse swap-in shared memory: ",
                      cudaGetErrorString(attribute_error));
      configured[device_index] = smem_bytes;
    }
  }
  kernel<<<launch_rows, kBlockSize, smem_bytes, stream>>>(
      hot_block_table.const_data_ptr<int32_t>(),
      global_indices.const_data_ptr<int32_t>(), request_ids_ptr,
      source_block_table_ptr, resident_block_table_ptr, valid_counts_ptr,
      swap_host_physical_rows_ptr, swap_device_physical_rows_ptr,
      swap_counts_ptr, hot_indices.mutable_data_ptr<int32_t>(),
      attention_indices_ptr, device_global_indices.mutable_data_ptr<int32_t>(),
      lru_slots.mutable_data_ptr<int16_t>(), stats_ptr, request_state_ptr,
      request_state_count, host_rows, hot_block_table.stride(0), hot_block_size,
      top_k, hot_size, hash_size, static_cast<int32_t>(max_union_rows),
      region_stride, attention_block_stride, source_bt_stride, source_num_reqs,
      source_num_blocks, static_cast<int32_t>(source_block_size),
      resident_bt_stride, resident_num_reqs, resident_num_blocks,
      static_cast<int32_t>(resident_block_size), global_indices.stride(0),
      attention_row_stride, valid_count_stride, num_valid_rows_ptr);
  const cudaError_t launch_error = cudaGetLastError();
  STD_TORCH_CHECK(launch_error == cudaSuccess,
                  "HiSparse residency kernel launch failed: ",
                  cudaGetErrorString(launch_error));
}

void hisparse_gather_plan(torch::stable::Tensor const& host_cache,
                          torch::stable::Tensor& hot_cache,
                          torch::stable::Tensor const& global_indices,
                          torch::stable::Tensor const& hot_indices,
                          torch::stable::Tensor const& miss_mask) {
  STD_TORCH_CHECK(
      host_cache.device().is_cpu() && is_pinned_cpu_tensor(host_cache),
      "host_cache must be pinned CPU memory");
  STD_TORCH_CHECK(hot_cache.is_cuda(), "hot_cache must be on CUDA");
  STD_TORCH_CHECK(
      global_indices.is_cuda() && hot_indices.is_cuda() && miss_mask.is_cuda(),
      "plan tensors must be on CUDA");
  STD_TORCH_CHECK(
      global_indices.scalar_type() == torch::headeronly::ScalarType::Int &&
          hot_indices.scalar_type() == torch::headeronly::ScalarType::Int &&
          miss_mask.scalar_type() == torch::headeronly::ScalarType::Int,
      "plan tensors must be int32");
  STD_TORCH_CHECK(global_indices.dim() == 2 && global_indices.is_contiguous(),
                  "global_indices must be contiguous 2D");
  STD_TORCH_CHECK(
      hot_indices.size(0) == global_indices.size(0) &&
          hot_indices.size(1) == global_indices.size(1) &&
          miss_mask.size(0) == global_indices.size(0) &&
          miss_mask.size(1) == global_indices.size(1) &&
          hot_indices.is_contiguous() && miss_mask.is_contiguous(),
      "hot_indices/miss_mask must match contiguous 2D global_indices");

  STD_TORCH_CHECK(hot_cache.dim() == 3,
                  "hot_cache must be [num_blocks, block_size, row_width]");
  const int64_t row_bytes = hot_cache.size(-1) * hot_cache.element_size();
  STD_TORCH_CHECK(row_bytes % 16 == 0, "KV rows must be 16-byte aligned");
  STD_TORCH_CHECK(hot_cache.stride(1) * hot_cache.element_size() == row_bytes,
                  "hot-cache rows must be contiguous");
  const int64_t host_rows = check_2d_rows(host_cache, "host_cache", row_bytes);

  const auto num_rows = static_cast<int32_t>(global_indices.size(0));
  const auto top_k = static_cast<int32_t>(global_indices.size(1));
  if (num_rows == 0 || top_k == 0) {
    return;
  }

  constexpr int kBlockSize = 1024;
  constexpr int kNumWarps = kBlockSize / kWarpSize;
  // Interleave columns over enough blocks per row to cover the device even
  // for the staging plan's single row, keeping >= 1 column per warp.
  constexpr int kTargetBlocks = 256;
  const int max_chunks = std::max(1, (top_k + kNumWarps - 1) / kNumWarps);
  const int num_chunks =
      std::min(max_chunks, std::max(1, kTargetBlocks / num_rows));
  const dim3 grid(num_rows, num_chunks);
  const int32_t hot_block_size = static_cast<int32_t>(hot_cache.size(1));
  const int64_t hot_rows = hot_cache.size(0) * hot_block_size;
  const int64_t hot_block_stride =
      hot_cache.stride(0) * hot_cache.element_size();
  const torch::stable::accelerator::DeviceGuard device_guard(
      hot_cache.get_device_index());
  const cudaStream_t stream = get_current_cuda_stream();
  hisparse_gather_plan_kernel<<<grid, kBlockSize, 0, stream>>>(
      static_cast<const char*>(host_cache.const_data_ptr()),
      static_cast<char*>(hot_cache.mutable_data_ptr()),
      global_indices.const_data_ptr<int32_t>(),
      hot_indices.const_data_ptr<int32_t>(),
      miss_mask.const_data_ptr<int32_t>(), host_rows, hot_rows, row_bytes,
      hot_block_stride, hot_block_size, top_k);
}

void hisparse_gather_compact(torch::stable::Tensor const& host_cache,
                             torch::stable::Tensor& hot_cache,
                             torch::stable::Tensor const& miss_global_indices,
                             torch::stable::Tensor const& miss_hot_indices,
                             torch::stable::Tensor const& miss_counts) {
  STD_TORCH_CHECK(
      host_cache.device().is_cpu() && is_pinned_cpu_tensor(host_cache),
      "host_cache must be pinned CPU memory");
  STD_TORCH_CHECK(hot_cache.is_cuda(), "hot_cache must be on CUDA");
  STD_TORCH_CHECK(
      miss_global_indices.is_cuda() && miss_hot_indices.is_cuda() &&
          miss_counts.is_cuda() &&
          miss_global_indices.scalar_type() ==
              torch::headeronly::ScalarType::Int &&
          miss_hot_indices.scalar_type() ==
              torch::headeronly::ScalarType::Int &&
          miss_counts.scalar_type() == torch::headeronly::ScalarType::Int &&
          miss_global_indices.dim() == 2 && miss_hot_indices.dim() == 2 &&
          miss_global_indices.size(0) == miss_hot_indices.size(0) &&
          miss_global_indices.size(1) == miss_hot_indices.size(1) &&
          miss_counts.numel() >= miss_global_indices.size(0) &&
          miss_global_indices.is_contiguous() &&
          miss_hot_indices.is_contiguous() && miss_counts.is_contiguous(),
      "compact miss plan must be matching contiguous int32 CUDA tensors");
  STD_TORCH_CHECK(hot_cache.dim() == 3,
                  "hot_cache must be [num_blocks, block_size, row_width]");
  const int64_t row_bytes = hot_cache.size(-1) * hot_cache.element_size();
  STD_TORCH_CHECK(row_bytes % 16 == 0, "KV rows must be 16-byte aligned");
  STD_TORCH_CHECK(hot_cache.stride(1) * hot_cache.element_size() == row_bytes,
                  "hot-cache rows must be contiguous");
  const int64_t host_rows = check_2d_rows(host_cache, "host_cache", row_bytes);
  const auto num_rows = static_cast<int32_t>(miss_global_indices.size(0));
  const auto top_k = static_cast<int32_t>(miss_global_indices.size(1));
  if (num_rows == 0 || top_k == 0) {
    return;
  }

  constexpr int kBlockSize = 512;
  constexpr int kTargetBlocks = 64;
  const int num_chunks = std::min(8, std::max(1, kTargetBlocks / num_rows));
  // Keep copy occupancy bounded when speculative verification adds more rows.
  const dim3 grid(std::min(num_rows, kTargetBlocks), num_chunks);
  const int32_t hot_block_size = static_cast<int32_t>(hot_cache.size(1));
  const int64_t hot_rows = hot_cache.size(0) * hot_block_size;
  const int64_t hot_block_stride =
      hot_cache.stride(0) * hot_cache.element_size();
  const torch::stable::accelerator::DeviceGuard device_guard(
      hot_cache.get_device_index());
  const cudaStream_t stream = get_current_cuda_stream();
  hisparse_gather_compact_kernel<<<grid, kBlockSize, 0, stream>>>(
      static_cast<const char*>(host_cache.const_data_ptr()),
      static_cast<char*>(hot_cache.mutable_data_ptr()),
      miss_global_indices.const_data_ptr<int32_t>(),
      miss_hot_indices.const_data_ptr<int32_t>(),
      miss_counts.const_data_ptr<int32_t>(), host_rows, hot_rows, row_bytes,
      hot_block_stride, hot_block_size, top_k, num_rows);
}
