# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

import io
import json
import unittest
import urllib.error
from typing import Any
from unittest.mock import patch

from run_ci_command import (
    CANCELABLE_BUILD_STATES,
    CI_AUTHORIZED_COMMENT_MARKER,
    COMMAND_CANCEL_AMD_CI,
    COMMAND_CANCEL_CI,
    COMMAND_RETRY_AMD_FAILED,
    COMMAND_RETRY_FAILED,
    COMMAND_ROCM_CACHE,
    COMMAND_ROCM_NOCACHE,
    COMMAND_RUN_AMD_CI,
    COMMAND_RUN_AMD_CI_ALL,
    COMMAND_RUN_AMD_CI_NIGHTLY,
    COMMAND_RUN_CI,
    COMMAND_RUN_CI_ALL,
    COMMAND_RUN_CI_NIGHTLY,
    RETRY_STATES,
    ROCM_CACHE_MARKER,
    RUN_CI_COMMAND_ENV,
    ApiError,
    BuildkiteClient,
    GitHubClient,
    HttpTransport,
    authorize,
    create_build_payload,
    has_trusted_approval,
    is_active_build,
    is_build_for_pr,
    is_ci_command_attempt,
    iter_builds,
    notify_authorized,
    parse_command,
    parse_trusted_users,
    pipeline_for_command,
    reply_unrecognized_command,
    resolve_workflow_run_pr,
    run,
    select_latest_build,
)


def make_pr(**overrides: Any) -> dict[str, Any]:
    pr = {
        "base": {"ref": "main"},
        "created_at": "2026-01-01T00:00:00Z",
        "draft": False,
        "head": {
            "label": "contributor:feature",
            "ref": "feature",
            "repo": {"clone_url": "https://github.com/contributor/vllm.git"},
            "sha": "0123456789abcdef",
        },
        "labels": [],
        "number": 42,
        "state": "open",
        "user": {"login": "author"},
    }
    pr.update(overrides)
    return pr


def make_event(command: str, actor: str = "reviewer") -> dict[str, Any]:
    return {
        "comment": {
            "body": command,
            "id": 99,
            "user": {"login": actor},
        },
        "issue": {
            "number": 42,
            "pull_request": {},
        },
    }


class FakeGitHub:
    def __init__(
        self,
        *,
        permission: str = "write",
        permissions: dict[str, str] | None = None,
        pr: dict[str, Any] | None = None,
        review_decision: str = "REVIEW_REQUIRED",
        reviews: list[dict[str, Any]] | None = None,
        comments: list[str] | None = None,
        pulls_for_commit: list[dict[str, Any]] | None = None,
        prs: dict[int, dict[str, Any]] | None = None,
        behind: int = 0,
        files: list[str] | None = None,
    ) -> None:
        self.comments = comments or []
        self.files = files or []
        # (path, ref) -> blob; main and the PR head share every blob by default.
        self.file_shas: dict[tuple[str, str], str] = {}
        self.permission = permission
        self.permissions = permissions or {}
        self.pr = pr or make_pr()
        self.reactions: list[str] = []
        self.review_decision = review_decision
        self.reviews = reviews or []
        self.pulls_for_commit = pulls_for_commit or []
        self.prs = prs or {self.pr["number"]: self.pr}
        self.behind = behind
        self.lag_queries: list[tuple[str, str]] = []

    def get_commits_behind_base(self, base_ref: str, head_sha: str) -> int:
        self.lag_queries.append((base_ref, head_sha))
        return self.behind

    def get_pr(self, number: int) -> dict[str, Any]:
        try:
            return self.prs[number]
        except KeyError as error:
            raise ApiError(404, "Not found") from error

    def get_permission(self, actor: str) -> str:
        return self.permissions.get(actor, self.permission)

    def list_pulls_for_commit(self, commit: str) -> list[dict[str, Any]]:
        return self.pulls_for_commit

    def get_review_decision(self, number: int) -> str:
        return self.review_decision

    def list_reviews(self, number: int) -> list[dict[str, Any]]:
        return self.reviews

    def list_issue_comments(self, number: int) -> list[dict[str, Any]]:
        return [
            {
                "body": body,
                "user": {"login": "github-actions[bot]"},
            }
            for body in self.comments
        ]

    def list_reactions(self, comment_id: int) -> list[dict[str, Any]]:
        return []

    def add_reaction(self, comment_id: int, content: str) -> None:
        self.reactions.append(content)

    def add_comment(self, issue_number: int, body: str) -> None:
        self.comments.append(body)

    def list_pr_files(self, number: int) -> list[str]:
        return self.files

    def get_file_sha(self, path: str, ref: str) -> str:
        return self.file_shas.get((path, ref), "blob")


class FakeBranchUpdater:
    def __init__(self, github: FakeGitHub, error: ApiError | None = None) -> None:
        self.calls: list[tuple[int, str]] = []
        self.error = error
        self.github = github

    def update_branch(self, number: int, expected_head_sha: str) -> None:
        self.calls.append((number, expected_head_sha))
        if self.error:
            raise self.error
        self.github.prs[number] = {
            **self.github.prs[number],
            "head": {**self.github.prs[number]["head"], "sha": "merge-commit-sha"},
        }
        self.github.behind = 0


class FakeBuildkite:
    def __init__(
        self,
        build_lists: list[list[dict[str, Any]]] | None = None,
        failed_job_lists: list[list[dict[str, Any]]] | None = None,
    ) -> None:
        self.build_lists = build_lists or []
        self.created_builds: list[dict[str, Any]] = []
        self.failed_job_lists = failed_job_lists or []
        self.job_list_calls: list[int] = []
        self.list_calls: list[tuple[str | None, tuple[str, str] | None]] = []
        self.list_requests: list[dict[str, Any]] = []
        self.retry_calls: list[tuple[int, str]] = []
        self.cancel_calls: list[int] = []

    def list_builds(
        self,
        commit: str | None,
        *,
        branch: str | None = None,
        metadata: tuple[str, str] | None = None,
        states: tuple[str, ...] = (),
        page: int = 1,
        created_from: str | None = None,
    ) -> list[dict[str, Any]]:
        self.list_calls.append((commit, metadata))
        self.list_requests.append(
            {
                "branch": branch,
                "commit": commit,
                "created_from": created_from,
                "metadata": metadata,
                "page": page,
                "states": states,
            }
        )
        return self.build_lists.pop(0)

    def create_build(self, body: dict[str, Any]) -> dict[str, Any]:
        self.created_builds.append(body)
        return {
            "number": 123,
            "web_url": "https://buildkite.example/builds/123",
        }

    def retry_failed_jobs(
        self,
        build_number: int,
        states: str,
    ) -> dict[str, Any]:
        self.retry_calls.append((build_number, states))
        return {"retried_jobs_count": 3}

    def cancel_build(self, build_number: int) -> dict[str, Any]:
        self.cancel_calls.append(build_number)
        return {"number": build_number, "state": "canceling"}

    def list_failed_jobs(self, build_number: int) -> list[dict[str, Any]]:
        self.job_list_calls.append(build_number)
        return self.failed_job_lists.pop(0)


class FakeTransport:
    def __init__(self, response: Any) -> None:
        self.calls: list[dict[str, Any]] = []
        self.response = response

    def request(self, url: str, **kwargs: Any) -> Any:
        self.calls.append({"url": url, **kwargs})
        if isinstance(self.response, tuple):
            return self.response[len(self.calls) - 1]
        return self.response


class FakeHttpResponse:
    def __init__(self, response: Any) -> None:
        self.response = response

    def __enter__(self) -> "FakeHttpResponse":
        return self

    def __exit__(self, *args: Any) -> None:
        return None

    def read(self) -> bytes:
        return json.dumps(self.response).encode()


class RunCiCommandTest(unittest.TestCase):
    @patch("run_ci_command.urllib.request.urlopen")
    def test_http_transport_retries_buildkite_rate_limit(self, urlopen: Any) -> None:
        body = {
            "message": "Please wait 9 seconds before making more requests.",
            "reset": 9,
            "scope": "rest",
        }
        rate_limit_error = urllib.error.HTTPError(
            "https://api.buildkite.com/v2/builds",
            429,
            "Too Many Requests",
            {
                "RateLimit-Limit": "400",
                "RateLimit-Remaining": "0",
                "RateLimit-Reset": "9",
            },
            io.BytesIO(json.dumps(body).encode()),
        )
        urlopen.side_effect = [rate_limit_error, FakeHttpResponse({"ok": True})]
        delays: list[float] = []

        response = HttpTransport(
            jitter=lambda: 2.5,
            sleep=delays.append,
        ).request("https://api.buildkite.com/v2/builds")

        self.assertEqual(response, {"ok": True})
        self.assertEqual(delays, [11.5])
        self.assertEqual(urlopen.call_count, 2)

    @patch("run_ci_command.urllib.request.urlopen")
    def test_http_transport_retries_rate_limit_three_times(self, urlopen: Any) -> None:
        def rate_limit_error() -> urllib.error.HTTPError:
            body = {
                "message": "Please wait 9 seconds before making more requests.",
                "reset": 9,
                "scope": "rest",
            }
            return urllib.error.HTTPError(
                "https://api.buildkite.com/v2/builds",
                429,
                "Too Many Requests",
                {
                    "RateLimit-Limit": "400",
                    "RateLimit-Remaining": "0",
                    "RateLimit-Reset": "9",
                },
                io.BytesIO(json.dumps(body).encode()),
            )

        urlopen.side_effect = [rate_limit_error() for _ in range(4)]
        delays: list[float] = []

        with self.assertRaisesRegex(RuntimeError, "API returned 429"):
            HttpTransport(
                jitter=lambda: 2,
                sleep=delays.append,
            ).request("https://api.buildkite.com/v2/builds")

        self.assertEqual(delays, [11, 11, 11])
        self.assertEqual(urlopen.call_count, 4)

    @patch("run_ci_command.urllib.request.urlopen")
    def test_http_transport_does_not_retry_permission_error(self, urlopen: Any) -> None:
        permission_error = urllib.error.HTTPError(
            "https://api.github.com/repos/vllm-project/vllm/issues/1/comments",
            403,
            "Forbidden",
            {},
            io.BytesIO(b'{"message":"Resource not accessible by integration"}'),
        )
        urlopen.side_effect = permission_error
        delays: list[float] = []

        with self.assertRaisesRegex(
            RuntimeError,
            "Resource not accessible by integration",
        ):
            HttpTransport(
                jitter=lambda: 2,
                sleep=delays.append,
            ).request(
                "https://api.github.com/repos/vllm-project/vllm/issues/1/comments"
            )

        self.assertEqual(delays, [])
        self.assertEqual(urlopen.call_count, 1)

    def test_only_exact_ci_commands_are_accepted(self) -> None:
        commands = (
            COMMAND_RUN_CI,
            COMMAND_RUN_CI_ALL,
            COMMAND_RUN_CI_NIGHTLY,
            COMMAND_RETRY_FAILED,
            COMMAND_CANCEL_CI,
            COMMAND_RUN_AMD_CI,
            COMMAND_RUN_AMD_CI_ALL,
            COMMAND_RUN_AMD_CI_NIGHTLY,
            COMMAND_RETRY_AMD_FAILED,
            COMMAND_CANCEL_AMD_CI,
        )
        for command in commands:
            with self.subTest(command=command):
                self.assertEqual(parse_command(command), command)
                override = f"{command} --allow-stale"
                if " run" in command:
                    self.assertEqual(parse_command(override), override)
                else:
                    self.assertIsNone(parse_command(override))

        self.assertIsNone(parse_command("/ci run please"))
        self.assertIsNone(parse_command("/ci run all please"))
        self.assertIsNone(parse_command("/ci cancel please"))
        self.assertIsNone(parse_command("/amd-ci run please"))
        self.assertIsNone(parse_command("/AMD-CI run"))
        self.assertIsNone(parse_command("/amdci run"))
        self.assertIsNone(parse_command("/ci run --allow-stale all"))
        self.assertIsNone(parse_command("/amd-ci run --allow-stale please"))

    def test_surrounding_whitespace_is_ignored(self) -> None:
        self.assertEqual(parse_command("/ci run\r\n"), COMMAND_RUN_CI)
        self.assertEqual(parse_command(" /ci run "), COMMAND_RUN_CI)
        self.assertEqual(parse_command("/amd-ci retry\n"), COMMAND_RETRY_AMD_FAILED)

    def test_ci_command_attempts_are_detected(self) -> None:
        for body in ("/ci", "/ci rn", "/CI run", "/amd-ci run please", " /ci\nrun"):
            with self.subTest(body=body):
                self.assertTrue(is_ci_command_attempt(body))
        for body in ("", "LGTM", "/cifoo", "/amdci run", "please /ci run"):
            with self.subTest(body=body):
                self.assertFalse(is_ci_command_attempt(body))

    def test_unrecognized_command_gets_feedback(self) -> None:
        github = FakeGitHub()

        reply_unrecognized_command(make_event("/ci rn", actor="author"), github)

        self.assertEqual(github.reactions, ["-1"])
        self.assertEqual(len(github.comments), 1)
        self.assertIn(
            "@author, that is not a recognized CI command", github.comments[0]
        )
        self.assertIn(f"`{COMMAND_RUN_CI}`", github.comments[0])
        self.assertIn("<!-- vllm-ci-command:99 -->", github.comments[0])

    def test_unrecognized_command_feedback_is_not_repeated(self) -> None:
        github = FakeGitHub(comments=["❌ earlier\n\n<!-- vllm-ci-command:99 -->"])

        reply_unrecognized_command(make_event("/ci rn"), github)

        self.assertEqual(len(github.comments), 1)
        self.assertEqual(github.reactions, [])

    def test_commands_select_only_their_configured_pipeline(self) -> None:
        cases = (
            (COMMAND_RUN_CI, "ci"),
            (COMMAND_RUN_CI_ALL, "ci"),
            (COMMAND_RUN_CI_NIGHTLY, "ci"),
            (COMMAND_RETRY_FAILED, "ci"),
            (COMMAND_CANCEL_CI, "ci"),
            (COMMAND_RUN_AMD_CI, "amd-ci"),
            (COMMAND_RUN_AMD_CI_ALL, "amd-ci"),
            (COMMAND_RUN_AMD_CI_NIGHTLY, "amd-ci"),
            (COMMAND_RETRY_AMD_FAILED, "amd-ci"),
            (COMMAND_CANCEL_AMD_CI, "amd-ci"),
        )
        for command, expected_pipeline in cases:
            with self.subTest(command=command):
                self.assertEqual(
                    pipeline_for_command(command),
                    expected_pipeline,
                )
        with self.assertRaisesRegex(ValueError, "Unsupported CI command"):
            pipeline_for_command("/amd-ci run arbitrary-pipeline")

    def test_write_access_authorizes_reviewers_and_authors(self) -> None:
        allowed, _ = authorize(
            actor="reviewer",
            permission="write",
            pr=make_pr(),
        )
        self.assertTrue(allowed)

    def test_configured_trusted_contributors_can_run_ci(self) -> None:
        trusted_users = parse_trusted_users("trusted-one, TRUSTED-TWO")
        allowed, _ = authorize(
            actor="trusted-two",
            permission="read",
            pr=make_pr(),
            trusted_users=trusted_users,
        )
        self.assertTrue(allowed)

    def test_authors_need_an_approval_or_ready_label(self) -> None:
        pending, _ = authorize(
            actor="author",
            permission="read",
            pr=make_pr(),
        )
        approved, _ = authorize(
            actor="author",
            permission="read",
            pr=make_pr(),
            trusted_approval=True,
        )
        ready, _ = authorize(
            actor="author",
            permission="read",
            pr=make_pr(labels=[{"name": "ready"}]),
        )
        self.assertFalse(pending)
        self.assertTrue(approved)
        self.assertTrue(ready)

    def test_non_author_contributors_without_write_are_denied(self) -> None:
        allowed, _ = authorize(
            actor="contributor",
            permission="read",
            pr=make_pr(),
            trusted_approval=True,
        )
        self.assertFalse(allowed)

    def test_authors_cannot_use_ready_state_on_draft_prs(self) -> None:
        allowed, _ = authorize(
            actor="author",
            permission="read",
            pr=make_pr(draft=True, labels=[{"name": "ready"}]),
            trusted_approval=True,
        )
        self.assertFalse(allowed)

    def test_only_trusted_reviewers_can_delegate_through_approval(self) -> None:
        approved_review = {
            "state": "APPROVED",
            "user": {"login": "reviewer"},
        }
        trusted = FakeGitHub(
            permission="read",
            permissions={"reviewer": "write"},
            review_decision="APPROVED",
            reviews=[approved_review],
        )
        untrusted = FakeGitHub(
            permission="read",
            review_decision="APPROVED",
            reviews=[approved_review],
        )
        self.assertTrue(has_trusted_approval(trusted, 42, set()))
        self.assertFalse(has_trusted_approval(untrusted, 42, set()))

    def test_build_matching_is_scoped_to_the_pr(self) -> None:
        self.assertTrue(is_build_for_pr({"pull_request": {"id": 42}}, 42))
        self.assertFalse(is_build_for_pr({"pull_request": {"id": 43}}, 42))
        self.assertTrue(
            is_build_for_pr(
                {"meta_data": {"github-pr-number": "42"}},
                42,
            )
        )

    def test_latest_build_selection_ignores_other_prs(self) -> None:
        latest = select_latest_build(
            [
                {
                    "created_at": "2026-07-28T02:00:00Z",
                    "number": 3,
                    "pull_request": {"id": 43},
                },
                {
                    "created_at": "2026-07-28T01:00:00Z",
                    "number": 2,
                    "pull_request": {"id": 42},
                },
                {
                    "created_at": "2026-07-28T00:00:00Z",
                    "number": 1,
                    "pull_request": {"id": 42},
                },
            ],
            42,
        )
        self.assertEqual(latest["number"], 2)

    def test_active_build_states_prevent_duplicate_runs(self) -> None:
        self.assertTrue(is_active_build({"state": "scheduled"}))
        self.assertTrue(is_active_build({"state": "running"}))
        self.assertTrue(is_active_build({"state": "waiting"}))
        self.assertTrue(is_active_build({"blocked": True, "state": "passed"}))
        self.assertFalse(is_active_build({"state": "failed"}))

    def test_build_payload_preserves_pr_context(self) -> None:
        payload = create_build_payload(
            actor="reviewer",
            comment_id=99,
            pr=make_pr(labels=[{"name": "ready"}, {"name": "v1"}]),
        )
        self.assertEqual(
            payload,
            {
                "commit": "0123456789abcdef",
                "branch": "contributor:feature",
                "message": "PR #42 /ci run by @reviewer",
                "pull_request_id": 42,
                "pull_request_base_branch": "main",
                "pull_request_repository": ("https://github.com/contributor/vllm.git"),
                "pull_request_labels": ["ready", "v1"],
                "env": {
                    "VLLM_CI_GITHUB_COMMENT_ID": "99",
                    "VLLM_CI_TRIGGERED_BY": "reviewer",
                },
                "meta_data": {
                    "github-comment-id": "99",
                    "github-pr-number": "42",
                    "github-triggered-by": "reviewer",
                },
            },
        )

    def test_build_payload_uses_head_label_to_avoid_branch_collision(self) -> None:
        pr = make_pr()
        pr["head"]["ref"] = "main"
        pr["head"]["label"] = "contributor:main"

        payload = create_build_payload(actor="reviewer", comment_id=99, pr=pr)

        self.assertEqual(payload["branch"], "contributor:main")

    def test_build_payload_falls_back_to_ref_without_label(self) -> None:
        pr = make_pr()
        del pr["head"]["label"]

        payload = create_build_payload(actor="reviewer", comment_id=99, pr=pr)

        self.assertEqual(payload["branch"], "feature")

    def test_write_reviewer_runs_ci_without_delegation(self) -> None:
        github = FakeGitHub()
        buildkite = FakeBuildkite([[], []])
        run(make_event(COMMAND_RUN_CI), github, buildkite)

        self.assertEqual(len(buildkite.created_builds), 1)
        self.assertEqual(
            buildkite.created_builds[0]["message"],
            "PR #42 /ci run by @reviewer",
        )
        self.assertEqual(github.reactions, ["eyes", "rocket"])
        self.assertTrue(github.comments[0].startswith("✅ "))
        self.assertIn("Buildkite CI #123", github.comments[0])

    def test_run_variants_require_current_base_without_changing_commit(self) -> None:
        for command in RUN_CI_COMMAND_ENV:
            if command.endswith(" --allow-stale"):
                continue
            for behind in (0, 1, 5):
                with self.subTest(command=command, behind=behind):
                    github = FakeGitHub(
                        behind=behind, pr=make_pr(base={"ref": "release/1.0"})
                    )
                    buildkite = FakeBuildkite([[], []])
                    run(make_event(command), github, buildkite)

                    self.assertEqual(
                        github.lag_queries,
                        [("release/1.0", github.pr["head"]["sha"])],
                    )
                    if behind == 0:
                        self.assertEqual(
                            buildkite.created_builds[0]["commit"],
                            github.pr["head"]["sha"],
                        )
                        self.assertIn(
                            "](https://buildkite.example/builds/123)",
                            github.comments[0],
                        )
                    else:
                        self.assertEqual(buildkite.created_builds, [])
                        self.assertTrue(github.comments[0].startswith("❌ "))
                        self.assertIn(str(behind), github.comments[0])
                        self.assertIn("upstream `release/1.0`", github.comments[0])
                        self.assertIn("every commit", github.comments[0])
                        self.assertIn(
                            "No new CI build was started.", github.comments[0]
                        )
                        self.assertIn(command, github.comments[0])

    def test_run_merges_base_into_outdated_branch_before_building(self) -> None:
        github = FakeGitHub(behind=5)
        updater = FakeBranchUpdater(github)
        buildkite = FakeBuildkite([[], []])

        with patch("run_ci_command.time.sleep"):
            run(make_event(COMMAND_RUN_CI), github, buildkite, "", updater)

        self.assertEqual(updater.calls, [(42, "0123456789abcdef")])
        self.assertEqual(buildkite.created_builds[0]["commit"], "merge-commit-sha")
        self.assertTrue(github.comments[0].startswith("✅ "))
        self.assertIn("5 commits behind", github.comments[0])
        self.assertIn("Merged upstream `main`", github.comments[0])

    def test_only_committers_can_rerun_a_commit_that_already_ran_ci(self) -> None:
        finished_build = {
            "created_at": "2026-07-28T01:00:00Z",
            "pull_request": {"id": 42},
            "state": "failed",
            "web_url": "https://buildkite.example/builds/122",
        }
        for actor, permission, command, allowed in (
            ("author", "read", COMMAND_RUN_CI, False),
            ("author", "read", f"{COMMAND_RUN_CI} --allow-stale", False),
            ("reviewer", "write", COMMAND_RUN_CI, True),
        ):
            with self.subTest(actor=actor, command=command):
                github = FakeGitHub(
                    behind=5,
                    permission=permission,
                    pr=make_pr(labels=[{"name": "ready"}]),
                )
                updater = FakeBranchUpdater(github)
                buildkite = FakeBuildkite([[], [finished_build]])

                with patch("run_ci_command.time.sleep"):
                    run(make_event(command, actor), github, buildkite, "", updater)

                self.assertEqual(bool(buildkite.created_builds), allowed)
                if not allowed:
                    self.assertEqual(updater.calls, [])
                    self.assertIn("CI already ran on this commit", github.comments[0])
                    self.assertIn("`/ci retry`", github.comments[0])

    def test_run_waits_for_fork_merge_commit_to_reach_base_repo(self) -> None:
        github = FakeGitHub(behind=5)
        updater = FakeBranchUpdater(github)
        buildkite = FakeBuildkite([[], []])

        with (
            patch("run_ci_command.time.sleep"),
            patch.object(
                github,
                "get_commits_behind_base",
                side_effect=[5, ApiError(404, "Not Found"), 0],
            ),
        ):
            run(make_event(COMMAND_RUN_CI), github, buildkite, "", updater)

        self.assertEqual(buildkite.created_builds[0]["commit"], "merge-commit-sha")
        self.assertTrue(github.comments[0].startswith("✅ "))

    def test_run_reports_failed_merge_without_building(self) -> None:
        github = FakeGitHub(behind=5)
        updater = FakeBranchUpdater(github, error=ApiError(422, "merge conflict"))
        buildkite = FakeBuildkite([[], []])

        run(make_event(COMMAND_RUN_CI), github, buildkite, "", updater)

        self.assertEqual(buildkite.created_builds, [])
        self.assertTrue(github.comments[0].startswith("❌ "))
        self.assertIn("could not merge upstream `main`", github.comments[0])
        self.assertIn("merge conflict", github.comments[0])
        self.assertIn("No new CI build was started.", github.comments[0])
        self.assertIn("`/ci run --allow-stale`", github.comments[0])

    def test_allow_stale_preserves_author_permissions_and_run_configuration(
        self,
    ) -> None:
        cases = (
            (COMMAND_RUN_CI, "ci", {}),
            (COMMAND_RUN_CI_ALL, "ci", {"RUN_ALL": "1"}),
            (COMMAND_RUN_CI_NIGHTLY, "ci", {"RUN_ALL": "1", "NIGHTLY": "1"}),
            (COMMAND_RUN_AMD_CI, "amd-ci", {}),
            (COMMAND_RUN_AMD_CI_ALL, "amd-ci", {"RUN_ALL": "1"}),
            (
                COMMAND_RUN_AMD_CI_NIGHTLY,
                "amd-ci",
                {"RUN_ALL": "1", "NIGHTLY": "1"},
            ),
        )
        for original_command, pipeline, expected_env in cases:
            command = f"{original_command} --allow-stale"
            for ready, behind in ((False, 100), (True, 0), (True, 100)):
                with self.subTest(command=command, ready=ready, behind=behind):
                    github = FakeGitHub(
                        permission="read",
                        behind=behind,
                        pr=make_pr(
                            base={"ref": "feature/stack"},
                            labels=[{"name": "ready"}] if ready else [],
                        ),
                    )
                    buildkite = FakeBuildkite([[], []])

                    run(make_event(command, "author"), github, buildkite)

                    self.assertEqual(pipeline_for_command(command), pipeline)
                    if not ready:
                        self.assertEqual(buildkite.created_builds, [])
                        self.assertEqual(buildkite.list_calls, [])
                        self.assertEqual(github.lag_queries, [])
                        self.assertTrue(github.comments[0].startswith("❌ "))
                        continue
                    self.assertEqual(len(buildkite.created_builds), 1)
                    payload = buildkite.created_builds[0]
                    self.assertEqual(payload["commit"], github.pr["head"]["sha"])
                    self.assertEqual(
                        payload["pull_request_base_branch"], "feature/stack"
                    )
                    self.assertEqual(payload["message"], f"PR #42 {command} by @author")
                    self.assertEqual(
                        payload["env"],
                        {
                            "VLLM_CI_GITHUB_COMMENT_ID": "99",
                            "VLLM_CI_TRIGGERED_BY": "author",
                            **expected_env,
                        },
                    )
                    self.assertEqual(
                        github.lag_queries,
                        [("feature/stack", github.pr["head"]["sha"])],
                    )
                    self.assertIn(
                        "Buildkite AMD CI #123"
                        if pipeline == "amd-ci"
                        else "Buildkite CI #123",
                        github.comments[0],
                    )
                    if behind:
                        self.assertIn("100 commits behind", github.comments[0])
                        self.assertIn("upstream `feature/stack`", github.comments[0])
                        self.assertIn("Before merging", github.comments[0])
                        self.assertIn("latest PR commit", github.comments[0])
                        self.assertIn(original_command, github.comments[0])

    def test_base_lag_query_qualifies_branch_refs_and_validates_count(self) -> None:
        for base_ref, encoded_ref in (
            ("main", "main"),
            ("release/1.0", "release%2F1.0"),
            ("feature/stack", "feature%2Fstack"),
        ):
            for count in (0, 5, None, -1, True, "5"):
                with self.subTest(base_ref=base_ref, count=count):
                    transport = FakeTransport(
                        {} if count is None else {"behind_by": count}
                    )
                    github = GitHubClient("token", "vllm-project/vllm", transport)
                    if type(count) is int and count >= 0:
                        self.assertEqual(
                            github.get_commits_behind_base(base_ref, "head-sha"), count
                        )
                    else:
                        with self.assertRaises(ApiError):
                            github.get_commits_behind_base(base_ref, "head-sha")
                    self.assertEqual(
                        transport.calls[0]["url"],
                        "https://api.github.com/repos/vllm-project/vllm/compare/"
                        f"refs%2Fheads%2F{encoded_ref}...head-sha?per_page=1",
                    )
                    self.assertEqual(transport.calls[0]["method"], "GET")

    def test_unknown_lag_or_changed_pr_prevents_runs(self) -> None:
        for command in (
            COMMAND_RUN_CI,
            COMMAND_RUN_AMD_CI,
            f"{COMMAND_RUN_CI} --allow-stale",
            f"{COMMAND_RUN_AMD_CI} --allow-stale",
        ):
            for fault in ("api", "head", "closed", "base"):
                with self.subTest(command=command, fault=fault):
                    github = FakeGitHub()
                    buildkite = FakeBuildkite([[], []])

                    def check(
                        base_ref: str,
                        sha: str,
                        fault: str = fault,
                        github: FakeGitHub = github,
                    ) -> int:
                        if fault == "api":
                            raise ApiError(503, "Unavailable")
                        changed = make_pr()
                        if fault == "head":
                            changed["head"]["sha"] = "another-head"
                        elif fault == "closed":
                            changed["state"] = "closed"
                        else:
                            changed["base"]["ref"] = "another-base"
                        github.prs[42] = changed
                        return 0

                    with patch.object(
                        github, "get_commits_behind_base", side_effect=check
                    ):
                        run(make_event(command), github, buildkite)
                    self.assertEqual(buildkite.created_builds, [])
                    self.assertEqual(buildkite.retry_calls, [])
                    self.assertTrue(github.comments[0].startswith("❌ "))
                    self.assertNotIn("Triggered", github.comments[0])

    def test_amd_run_ignores_blocked_builds(self) -> None:
        for metadata in ({}, {"github-comment-id": "98"}):
            with self.subTest(metadata=metadata):
                github = FakeGitHub()
                blocked_build = {
                    "blocked": True,
                    "created_at": "2026-08-18T01:00:00Z",
                    "meta_data": metadata,
                    "number": 122,
                    "pull_request": {"id": 42},
                    "state": "blocked",
                    "web_url": "https://buildkite.example/amd-ci/builds/122",
                }
                buildkite = FakeBuildkite([[], [blocked_build]])

                run(make_event(COMMAND_RUN_AMD_CI_ALL), github, buildkite)

                self.assertEqual(len(buildkite.created_builds), 1)
                self.assertEqual(buildkite.created_builds[0]["env"]["RUN_ALL"], "1")

    def test_amd_run_deduplicates_comment_triggered_active_build(self) -> None:
        github = FakeGitHub()
        command_build = {
            "blocked": False,
            "created_at": "2026-08-18T01:00:00Z",
            "meta_data": {"github-comment-id": "98"},
            "number": 122,
            "pull_request": {"id": 42},
            "source": "api",
            "state": "running",
            "web_url": "https://buildkite.example/amd-ci/builds/122",
        }
        buildkite = FakeBuildkite([[], [command_build]])

        run(make_event(COMMAND_RUN_AMD_CI_ALL), github, buildkite)

        self.assertEqual(buildkite.created_builds, [])
        self.assertIn("AMD CI is already running", github.comments[0])

    def test_amd_run_ignores_finished_webhook_build_for_author(self) -> None:
        webhook_build = {
            "created_at": "2026-08-18T01:00:00Z",
            "meta_data": {},
            "number": 122,
            "pull_request": {"id": 42},
            "source": "webhook",
            "state": "passed",
            "web_url": "https://buildkite.example/amd-ci/builds/122",
        }
        ui_build = {**webhook_build, "source": "ui"}
        command_build = {
            **webhook_build,
            "meta_data": {"github-comment-id": "98"},
            "source": "api",
        }
        for build, allowed in (
            (webhook_build, True),
            (ui_build, False),
            (command_build, False),
        ):
            with self.subTest(source=build["source"]):
                github = FakeGitHub(
                    permission="read",
                    pr=make_pr(labels=[{"name": "ready"}]),
                )
                buildkite = FakeBuildkite([[], [build]])

                run(make_event(COMMAND_RUN_AMD_CI, "author"), github, buildkite)

                self.assertEqual(bool(buildkite.created_builds), allowed)
                if not allowed:
                    self.assertIn(
                        "AMD CI already ran on this commit", github.comments[0]
                    )

    def test_run_all_sets_buildkite_environment(self) -> None:
        github = FakeGitHub()
        buildkite = FakeBuildkite([[], []])

        run(make_event(COMMAND_RUN_CI_ALL), github, buildkite)

        payload = buildkite.created_builds[0]
        self.assertEqual(payload["message"], "PR #42 /ci run all by @reviewer")
        self.assertEqual(payload["env"]["RUN_ALL"], "1")
        self.assertNotIn("NIGHTLY", payload["env"])

    def test_run_nightly_sets_buildkite_environment(self) -> None:
        github = FakeGitHub()
        buildkite = FakeBuildkite([[], []])

        run(make_event(COMMAND_RUN_CI_NIGHTLY), github, buildkite)

        payload = buildkite.created_builds[0]
        self.assertEqual(payload["message"], "PR #42 /ci run nightly by @reviewer")
        self.assertEqual(payload["env"]["RUN_ALL"], "1")
        self.assertEqual(payload["env"]["NIGHTLY"], "1")

    def test_amd_run_variants_set_buildkite_environment(self) -> None:
        cases = (
            (COMMAND_RUN_AMD_CI, {}),
            (COMMAND_RUN_AMD_CI_ALL, {"RUN_ALL": "1"}),
            (
                COMMAND_RUN_AMD_CI_NIGHTLY,
                {"RUN_ALL": "1", "NIGHTLY": "1"},
            ),
        )
        for command, expected_env in cases:
            with self.subTest(command=command):
                github = FakeGitHub()
                buildkite = FakeBuildkite([[], []])

                run(make_event(command), github, buildkite)

                payload = buildkite.created_builds[0]
                self.assertEqual(payload["message"], f"PR #42 {command} by @reviewer")
                command_env = {
                    key: value
                    for key, value in payload["env"].items()
                    if key in {"RUN_ALL", "NIGHTLY"}
                }
                self.assertEqual(command_env, expected_env)
                self.assertIn("Buildkite AMD CI #123", github.comments[0])

    def test_unapproved_authors_are_denied_without_buildkite(self) -> None:
        github = FakeGitHub(
            permission="read",
            pr=make_pr(),
            review_decision="REVIEW_REQUIRED",
        )
        buildkite = FakeBuildkite()
        run(make_event(COMMAND_RUN_CI, "author"), github, buildkite)

        self.assertEqual(buildkite.list_calls, [])
        self.assertEqual(github.lag_queries, [])
        self.assertEqual(github.reactions, ["eyes"])
        self.assertTrue(github.comments[0].startswith("❌ "))
        self.assertIn("approve the PR", github.comments[0])

        run(make_event(COMMAND_RUN_CI, "author"), github, buildkite)
        self.assertEqual(len(github.comments), 1)

    def test_unapproved_author_gets_amd_specific_guidance(self) -> None:
        github = FakeGitHub(
            permission="read",
            pr=make_pr(),
            review_decision="REVIEW_REQUIRED",
        )
        buildkite = FakeBuildkite()

        run(make_event(COMMAND_RUN_AMD_CI, "author"), github, buildkite)

        self.assertEqual(buildkite.list_calls, [])
        self.assertIn("`/amd-ci run`", github.comments[0])
        self.assertNotIn("`/ci run`", github.comments[0])

    def test_untrusted_approval_cannot_launch_ci(self) -> None:
        github = FakeGitHub(
            permission="read",
            pr=make_pr(),
            review_decision="APPROVED",
            reviews=[
                {
                    "state": "APPROVED",
                    "user": {"login": "untrusted-reviewer"},
                }
            ],
        )
        buildkite = FakeBuildkite()

        run(make_event(COMMAND_RUN_CI, "author"), github, buildkite)

        self.assertEqual(buildkite.list_calls, [])
        self.assertEqual(github.reactions, ["eyes"])
        self.assertTrue(github.comments[0].startswith("❌ "))

    def test_ready_label_notifies_author_once(self) -> None:
        pr = make_pr(labels=[{"name": "ready"}])
        event = {
            "action": "labeled",
            "label": {"name": "ready"},
            "pull_request": pr,
        }
        github = FakeGitHub(permission="read", pr=pr)

        notify_authorized(event, github)
        notify_authorized(event, github)

        self.assertEqual(len(github.comments), 1)
        comment = github.comments[0]
        self.assertTrue(comment.startswith("✅ @author"))
        self.assertIn("`/ci run` starts upstream CI", comment)
        self.assertIn("`/ci retry` retries failed jobs", comment)
        self.assertIn("`/ci cancel` cancels scheduled or running", comment)
        self.assertIn("`/amd-ci run` starts AMD CI only", comment)
        self.assertIn("`/amd-ci retry` retries failed jobs in AMD CI", comment)
        self.assertIn("`/amd-ci cancel` does the same for AMD CI only", comment)
        self.assertIn("CI build for the current PR head", comment)
        self.assertIn("only jobs that failed in the latest earlier CI build", comment)
        self.assertNotIn(COMMAND_RUN_CI_ALL, comment)
        self.assertNotIn(COMMAND_RUN_CI_NIGHTLY, comment)
        self.assertIn(CI_AUTHORIZED_COMMENT_MARKER, comment)

    def test_ready_label_notifies_after_missed_approval_notification(self) -> None:
        pr = make_pr(labels=[{"name": "ready"}])
        event = {
            "action": "labeled",
            "label": {"name": "ready"},
            "pull_request": pr,
        }
        github = FakeGitHub(
            permission="read",
            permissions={"reviewer": "write"},
            pr=pr,
            review_decision="APPROVED",
            reviews=[
                {
                    "state": "APPROVED",
                    "user": {"login": "reviewer"},
                }
            ],
        )

        notify_authorized(event, github)

        self.assertEqual(len(github.comments), 1)
        self.assertIn("@author", github.comments[0])

    def test_trusted_approval_notifies_author_once(self) -> None:
        event = {
            "action": "submitted",
            "pull_request": make_pr(),
            "review": {"state": "approved"},
        }
        github = FakeGitHub(
            permission="read",
            permissions={"reviewer": "write"},
            review_decision="APPROVED",
            reviews=[
                {
                    "state": "APPROVED",
                    "user": {"login": "reviewer"},
                }
            ],
        )

        notify_authorized(event, github)
        notify_authorized(event, github)

        self.assertEqual(len(github.comments), 1)
        self.assertIn("@author", github.comments[0])

    def test_workflow_run_resolves_pr_from_head_commit(self) -> None:
        pr = make_pr()
        github = FakeGitHub(
            pr=pr,
            pulls_for_commit=[{"number": pr["number"]}],
        )

        resolved = resolve_workflow_run_pr(
            {"head_sha": pr["head"]["sha"], "pull_requests": []},
            github,
        )

        self.assertEqual(resolved, pr)

    def test_workflow_run_ignores_unrelated_pr_association(self) -> None:
        pr = make_pr()
        github = FakeGitHub(
            pr=pr,
            pulls_for_commit=[{"number": pr["number"]}],
        )

        resolved = resolve_workflow_run_pr(
            {
                "head_sha": pr["head"]["sha"],
                "pull_requests": [{"number": 1}],
            },
            github,
        )

        self.assertEqual(resolved, pr)

    def test_approval_does_not_notify_when_ready_label_exists(self) -> None:
        pr = make_pr(labels=[{"name": "ready"}])
        event = {
            "action": "submitted",
            "pull_request": pr,
            "review": {"state": "approved"},
        }
        github = FakeGitHub(
            permission="read",
            permissions={"reviewer": "write"},
            pr=pr,
            review_decision="APPROVED",
            reviews=[
                {
                    "state": "APPROVED",
                    "user": {"login": "reviewer"},
                }
            ],
        )

        notify_authorized(event, github)

        self.assertEqual(github.comments, [])

    def test_untrusted_approval_does_not_notify_author(self) -> None:
        event = {
            "action": "submitted",
            "pull_request": make_pr(),
            "review": {"state": "approved"},
        }
        github = FakeGitHub(
            permission="read",
            review_decision="APPROVED",
            reviews=[
                {
                    "state": "APPROVED",
                    "user": {"login": "reviewer"},
                }
            ],
        )

        notify_authorized(event, github)

        self.assertEqual(github.comments, [])

    def test_notification_skips_authors_who_already_have_write(self) -> None:
        pr = make_pr(labels=[{"name": "ready"}])
        event = {
            "action": "labeled",
            "label": {"name": "ready"},
            "pull_request": pr,
        }
        github = FakeGitHub(permission="write", pr=pr)

        notify_authorized(event, github)

        self.assertEqual(github.comments, [])

    def test_notification_skips_draft_prs(self) -> None:
        pr = make_pr(draft=True, labels=[{"name": "ready"}])
        event = {
            "action": "labeled",
            "label": {"name": "ready"},
            "pull_request": pr,
        }
        github = FakeGitHub(permission="read", pr=pr)

        notify_authorized(event, github)

        self.assertEqual(github.comments, [])

    def test_ci_retry_retries_failed_jobs_while_build_is_running(self) -> None:
        github = FakeGitHub(
            behind=100,
            permission="read",
            pr=make_pr(labels=[{"name": "ready"}]),
        )
        buildkite = FakeBuildkite(
            [
                [
                    {
                        "created_at": "2026-07-28T01:00:00Z",
                        "number": 123,
                        "pull_request": {"id": 42},
                        "state": "failing",
                        "web_url": "https://buildkite.example/builds/123",
                    }
                ]
            ]
        )
        run(make_event(COMMAND_RETRY_FAILED, "author"), github, buildkite)

        self.assertEqual(buildkite.retry_calls, [(123, RETRY_STATES)])
        self.assertEqual(github.lag_queries, [])
        self.assertIn("Queued 3 failed job", github.comments[0])

    def test_amd_ci_retry_retries_only_the_current_head_build(self) -> None:
        github = FakeGitHub(
            behind=100,
            permission="read",
            pr=make_pr(labels=[{"name": "ready"}]),
        )
        buildkite = FakeBuildkite(
            [
                [
                    {
                        "created_at": "2026-07-28T01:00:00Z",
                        "number": 321,
                        "pull_request": {"id": 42},
                        "state": "failing",
                        "web_url": "https://buildkite.example/amd-ci/builds/321",
                    }
                ]
            ]
        )

        run(make_event(COMMAND_RETRY_AMD_FAILED, "author"), github, buildkite)

        self.assertEqual(buildkite.retry_calls, [(321, RETRY_STATES)])
        self.assertEqual(github.lag_queries, [])
        self.assertIn("Buildkite AMD CI #321", github.comments[0])

    def test_amd_ci_retry_requires_a_build_for_the_current_head(self) -> None:
        github = FakeGitHub(
            permission="read",
            pr=make_pr(labels=[{"name": "ready"}]),
        )
        buildkite = FakeBuildkite([[]])

        run(make_event(COMMAND_RETRY_AMD_FAILED, "author"), github, buildkite)

        self.assertEqual(buildkite.list_calls, [("0123456789abcdef", None)])
        self.assertEqual(buildkite.retry_calls, [])
        self.assertEqual(buildkite.created_builds, [])
        self.assertIn(
            "No AMD CI build exists for the current PR head", github.comments[0]
        )
        self.assertIn("Use `/amd-ci run`", github.comments[0])

    def test_amd_ci_retry_ignores_webhook_build_for_the_current_head(self) -> None:
        github = FakeGitHub(
            permission="read",
            pr=make_pr(labels=[{"name": "ready"}]),
        )
        webhook_build = {
            "created_at": "2026-08-18T01:00:00Z",
            "meta_data": {},
            "number": 122,
            "pull_request": {"id": 42},
            "source": "webhook",
            "state": "passed",
            "web_url": "https://buildkite.example/amd-ci/builds/122",
        }
        buildkite = FakeBuildkite([[webhook_build]])

        run(make_event(COMMAND_RETRY_AMD_FAILED, "author"), github, buildkite)

        self.assertEqual(buildkite.retry_calls, [])
        self.assertIn(
            "No AMD CI build exists for the current PR head", github.comments[0]
        )

    def test_ci_retry_creates_filtered_build_for_new_head(self) -> None:
        github = FakeGitHub(
            behind=100,
            permission="read",
            pr=make_pr(labels=[{"name": "ready"}]),
        )
        source_build = {
            "commit": "old-commit",
            "created_at": "2026-07-28T01:00:00Z",
            "finished_at": "2026-07-28T02:00:00Z",
            "number": 122,
            "pull_request": {"id": 42},
            "state": "failed",
            "web_url": "https://buildkite.example/builds/122",
        }
        buildkite = FakeBuildkite(
            [[], [source_build]],
            [
                [
                    {
                        "state": "failed",
                        "step_key": "basic-models-test-other-cpu",
                        "type": "script",
                    },
                    {
                        "state": "failed",
                        "step_key": "basic-models-test-other-cpu",
                        "type": "script",
                    },
                    {
                        "state": "timed_out",
                        "step_key": "distributed-tests-2xh100-2xmi300",
                        "type": "script",
                    },
                ]
            ],
        )

        run(make_event(COMMAND_RETRY_FAILED, "author"), github, buildkite)

        self.assertEqual(buildkite.job_list_calls, [122])
        self.assertEqual(len(buildkite.created_builds), 1)
        payload = buildkite.created_builds[0]
        self.assertEqual(payload["commit"], "0123456789abcdef")
        self.assertEqual(github.lag_queries, [])
        self.assertEqual(payload["message"], "PR #42 /ci retry by @author")
        self.assertEqual(
            json.loads(payload["env"]["VLLM_CI_ONLY_STEP_KEYS"]),
            [
                "basic-models-test-other-cpu",
                "distributed-tests-2xh100-2xmi300",
            ],
        )
        self.assertEqual(
            payload["meta_data"]["github-retry-source-build"],
            "122",
        )
        self.assertEqual(
            payload["meta_data"]["github-retry-source-commit"],
            "old-commit",
        )
        self.assertIn("running 2 failed step", github.comments[0])
        self.assertIn("Buildkite CI #122", github.comments[0])

    def test_ci_retry_new_head_requires_stable_step_keys(self) -> None:
        github = FakeGitHub(
            permission="read",
            pr=make_pr(labels=[{"name": "ready"}]),
        )
        buildkite = FakeBuildkite(
            [
                [],
                [
                    {
                        "commit": "old-commit",
                        "created_at": "2026-07-28T01:00:00Z",
                        "finished_at": "2026-07-28T02:00:00Z",
                        "number": 122,
                        "pull_request": {"id": 42},
                        "state": "failed",
                        "web_url": "https://buildkite.example/builds/122",
                    }
                ],
            ],
            [[{"state": "failed", "step_key": None, "type": "script"}]],
        )

        run(make_event(COMMAND_RETRY_FAILED, "author"), github, buildkite)

        self.assertEqual(buildkite.created_builds, [])
        self.assertIn("without stable step keys", github.comments[0])
        self.assertIn("Use `/ci run`", github.comments[0])

    def test_ci_retry_new_head_rejects_incomplete_setup_failure(self) -> None:
        github = FakeGitHub(
            permission="read",
            pr=make_pr(labels=[{"name": "ready"}]),
        )
        buildkite = FakeBuildkite(
            [
                [],
                [
                    {
                        "commit": "old-commit",
                        "created_at": "2026-07-28T01:00:00Z",
                        "finished_at": "2026-07-28T02:00:00Z",
                        "number": 122,
                        "pull_request": {"id": 42},
                        "state": "failed",
                        "web_url": "https://buildkite.example/builds/122",
                    }
                ],
            ],
            [
                [
                    {
                        "state": "failed",
                        "step_key": "image-build",
                        "type": "script",
                    }
                ]
            ],
        )

        run(make_event(COMMAND_RETRY_FAILED, "author"), github, buildkite)

        self.assertEqual(buildkite.created_builds, [])
        self.assertIn("failed during CI setup", github.comments[0])
        self.assertIn("Use `/ci run`", github.comments[0])

    def test_buildkite_retry_uses_retry_failed_jobs_endpoint(self) -> None:
        transport = FakeTransport({"retried_jobs_count": 2})
        client = BuildkiteClient(
            "secret",
            "vllm",
            "ci",
            transport=transport,
        )
        client.retry_failed_jobs(123, RETRY_STATES)

        call = transport.calls[0]
        self.assertEqual(call["method"], "PUT")
        self.assertTrue(call["url"].endswith("/123/retry_failed_jobs"))
        self.assertEqual(call["body"], {"states": RETRY_STATES})

    def test_ci_cancel_cancels_active_builds_for_pr_branch(self) -> None:
        github = FakeGitHub()
        buildkite = FakeBuildkite(
            [
                # Builds created under the head label (owner:branch).
                [
                    {
                        "branch": "contributor:feature",
                        "number": 123,
                        "pull_request": {"id": 42},
                        "state": "running",
                        "web_url": "https://buildkite.example/builds/123",
                    },
                    {
                        "branch": "contributor:feature",
                        "number": 124,
                        "meta_data": {"github-pr-number": "42"},
                        "state": "failing",
                        "web_url": "https://buildkite.example/builds/124",
                    },
                    {
                        "branch": "contributor:feature",
                        "number": 125,
                        "pull_request": {"id": 43},
                        "state": "running",
                        "web_url": "https://buildkite.example/builds/125",
                    },
                    {
                        "branch": "contributor:feature",
                        "number": 127,
                        "pull_request": {"id": 42},
                        "state": "passed",
                        "web_url": "https://buildkite.example/builds/127",
                    },
                ],
                # Legacy builds created under the bare ref before the label change.
                [
                    {
                        "branch": "feature",
                        "number": 126,
                        "pull_request": {"id": 42},
                        "state": "running",
                        "web_url": "https://buildkite.example/builds/126",
                    },
                ],
            ]
        )

        run(make_event(COMMAND_CANCEL_CI), github, buildkite)

        self.assertEqual(buildkite.cancel_calls, [123, 124, 126])
        self.assertEqual(github.lag_queries, [])
        self.assertEqual(
            [request["branch"] for request in buildkite.list_requests],
            ["contributor:feature", "feature"],
        )
        self.assertIn("Requested cancellation of 3 CI builds", github.comments[0])
        self.assertIn("#123", github.comments[0])
        self.assertIn("#124", github.comments[0])
        self.assertIn("#126", github.comments[0])

    def test_ci_cancel_is_a_noop_without_active_builds(self) -> None:
        github = FakeGitHub()
        buildkite = FakeBuildkite([[], []])

        run(make_event(COMMAND_CANCEL_CI), github, buildkite)

        self.assertEqual(buildkite.cancel_calls, [])
        self.assertIn("No cancelable CI build is running", github.comments[0])

    def test_amd_ci_cancel_handles_command_and_fork_webhook_branches(self) -> None:
        pr = make_pr()
        pr["head"]["label"] = "contributor:feature"
        github = FakeGitHub(pr=pr)
        buildkite = FakeBuildkite(
            [
                [
                    {
                        "branch": "contributor:feature",
                        "number": 322,
                        "pull_request": {"id": 42},
                        "state": "failing",
                        "web_url": "https://buildkite.example/amd-ci/builds/322",
                    }
                ],
                [
                    {
                        "branch": "feature",
                        "number": 321,
                        "pull_request": {"id": 42},
                        "state": "running",
                        "web_url": "https://buildkite.example/amd-ci/builds/321",
                    }
                ],
            ]
        )

        run(make_event(COMMAND_CANCEL_AMD_CI), github, buildkite)

        self.assertEqual(buildkite.cancel_calls, [322, 321])
        self.assertEqual(github.lag_queries, [])
        self.assertEqual(
            [request["branch"] for request in buildkite.list_requests],
            ["contributor:feature", "feature"],
        )
        self.assertTrue(
            all(
                request["states"] == CANCELABLE_BUILD_STATES
                for request in buildkite.list_requests
            )
        )
        self.assertIn("cancellation of 2 AMD CI builds", github.comments[0])

    def test_buildkite_create_build_ignores_pipeline_branch_filters(self) -> None:
        transport = FakeTransport({"number": 123})
        client = BuildkiteClient(
            "secret",
            "vllm",
            "amd-ci",
            transport=transport,
        )

        client.create_build({"branch": "main", "commit": "HEAD"})

        call = transport.calls[0]
        self.assertEqual(call["method"], "POST")
        self.assertEqual(
            call["body"],
            {
                "branch": "main",
                "commit": "HEAD",
                "ignore_pipeline_branch_filters": True,
            },
        )

    def test_buildkite_cancel_uses_cancel_build_endpoint(self) -> None:
        transport = FakeTransport({"number": 123, "state": "canceling"})
        client = BuildkiteClient(
            "secret",
            "vllm",
            "ci",
            transport=transport,
        )

        client.cancel_build(123)

        call = transport.calls[0]
        self.assertEqual(call["method"], "PUT")
        self.assertTrue(call["url"].endswith("/123/cancel"))
        self.assertIsNone(call["body"])

    def test_buildkite_list_builds_allows_query_on_builds_endpoint(self) -> None:
        transport = FakeTransport([])
        client = BuildkiteClient(
            "secret",
            "vllm",
            "ci",
            transport=transport,
        )

        builds = client.list_builds(
            "current-commit",
            branch="feature",
            metadata=("github-pr-number", "42"),
            states=CANCELABLE_BUILD_STATES,
        )
        client.list_builds(None, page=2, created_from="2026-01-01T00:00:00Z")

        self.assertEqual(builds, [])
        self.assertNotIn("&page=", transport.calls[0]["url"])
        self.assertIn("&page=2", transport.calls[1]["url"])
        self.assertIn(
            "created_from=2026-01-01T00%3A00%3A00Z", transport.calls[1]["url"]
        )
        url = transport.calls[0]["url"]
        self.assertIn("?exclude_jobs=true", url)
        self.assertIn("commit=current-commit", url)
        self.assertIn("branch=feature", url)
        self.assertIn("meta_data%5Bgithub-pr-number%5D=42", url)
        self.assertIn("state%5B%5D=scheduled", url)
        self.assertIn("state%5B%5D=running", url)
        self.assertIn("state%5B%5D=failing", url)

    def test_buildkite_failed_jobs_follow_cursor_pagination(self) -> None:
        next_url = (
            "https://api.buildkite.com/v2/organizations/vllm/pipelines/ci/"
            "builds/123/jobs?after=cursor"
        )
        transport = FakeTransport(
            (
                {
                    "items": [{"id": "first"}],
                    "links": {"next": next_url},
                },
                {
                    "items": [{"id": "second"}],
                    "links": {"next": None},
                },
            )
        )
        client = BuildkiteClient(
            "secret",
            "vllm",
            "ci",
            transport=transport,
        )

        jobs = client.list_failed_jobs(123)

        self.assertEqual(jobs, [{"id": "first"}, {"id": "second"}])
        self.assertIn("state%5B%5D=failed", transport.calls[0]["url"])
        self.assertIn("include_retried_jobs=false", transport.calls[0]["url"])
        self.assertEqual(transport.calls[1]["url"], next_url)


STACK_PR_FILES = ["docker/Dockerfile.rocm_base"]
STACK_BUILT = {"rocm-rocm-stack-built": "s@d1 w@d2"}


def ci_build(**overrides: Any) -> dict[str, Any]:
    return {
        "commit": "fedcba9876543210",
        "created_at": "1",
        "meta_data": STACK_BUILT,
        "pull_request": {"id": 42},
        "web_url": "https://buildkite.example/ci/builds/2",
        **overrides,
    }


class RocmCacheTest(unittest.TestCase):
    def comment(
        self,
        github: FakeGitHub,
        command: str = COMMAND_ROCM_CACHE,
        ci_builds: list[dict[str, Any]] | None = None,
        actor: str = "reviewer",
        ci_pages: list[list[dict[str, Any]]] | None = None,
    ) -> FakeBuildkite:
        # One page per query: the head label, then the bare ref.
        amd = FakeBuildkite([[], []])
        self.ci = FakeBuildkite(ci_pages or [ci_builds or [], []])
        run(make_event(command, actor), github, amd, ci_buildkite=self.ci)
        return amd

    def test_commands_are_rocm_ci_commands_on_amd_ci(self) -> None:
        for command in (COMMAND_ROCM_CACHE, COMMAND_ROCM_NOCACHE):
            self.assertEqual(parse_command(command), command)
            self.assertEqual(pipeline_for_command(command), "amd-ci")

    def test_cache_copies_the_images_this_prs_ci_pushed(self) -> None:
        github = FakeGitHub(files=STACK_PR_FILES)
        builds = [
            ci_build(meta_data={"rocm-rocm-stack-built": "old"}, created_at="0"),
            # Built at an earlier commit: later ones (e.g. merging main) reuse it.
            ci_build(),
            ci_build(created_at="2", pull_request={"id": 7}),  # another PR
            # Metadata any job can write does not tie a build to this PR.
            ci_build(
                commit="0" * 16,
                created_at="3",
                pull_request=None,
                meta_data={"rocm-rocm-stack-built": "x@d9", "github-pr-number": "42"},
            ),
            # Reused a stack instead of pushing it: another PR's CI may have.
            ci_build(created_at="4", meta_data={"rocm-rocm-stack": "s@d3"}),
        ]

        amd = self.comment(github, ci_builds=builds)

        (build,) = amd.created_builds
        self.assertEqual((build["branch"], build["commit"]), ("main", "HEAD"))
        self.assertEqual(
            build["env"],
            {
                "ROCM_PROMOTE_PR": "42",
                "ROCM_PROMOTE_SHA": "fedcba9876543210",
                "ROCM_PROMOTE_IMAGES": "s@d1 w@d2",
            },
        )
        self.assertIn(ROCM_CACHE_MARKER, github.comments[0])
        self.assertIn("ci/builds/2", github.comments[0])
        self.assertIn("`fedcba987654`", github.comments[0])
        self.assertEqual(self.ci.list_requests[0]["branch"], "contributor:feature")

    def test_cache_finds_the_source_on_a_later_page(self) -> None:
        reused = ci_build(meta_data={"rocm-rocm-stack": "s@d3"})
        github = FakeGitHub(files=STACK_PR_FILES)

        amd = self.comment(github, ci_pages=[[reused] * 100, [ci_build()], []])

        self.assertEqual(len(amd.created_builds), 1)
        self.assertEqual(
            [(r["branch"], r["page"]) for r in self.ci.list_requests],
            [("contributor:feature", 1), ("contributor:feature", 2), ("feature", 1)],
        )

    def test_cache_lists_builds_since_the_pr_opened_off_the_base_branch(
        self,
    ) -> None:
        pr = make_pr(head={**make_pr()["head"], "label": "contributor:main"})
        pr["head"]["ref"] = "main"
        github = FakeGitHub(files=STACK_PR_FILES, pr=pr)

        amd = self.comment(github, ci_pages=[[ci_build()]])

        self.assertEqual(len(amd.created_builds), 1)
        self.assertEqual(
            [(r["branch"], r["created_from"]) for r in self.ci.list_requests],
            [("contributor:main", "2026-01-01T00:00:00Z")],
        )

    def test_build_pagination_is_bounded(self) -> None:
        full = FakeBuildkite([[ci_build()] * 100] * 101)

        with self.assertRaises(ApiError):
            list(iter_builds(full, branch="feature"))

    def test_cache_finds_a_source_created_under_the_bare_ref(self) -> None:
        github = FakeGitHub(files=STACK_PR_FILES)

        amd = self.comment(github, ci_pages=[[], [ci_build()]])

        (build,) = amd.created_builds
        self.assertEqual(build["env"]["ROCM_PROMOTE_SHA"], "fedcba9876543210")

    def test_nocache_records_the_decision_without_a_build(self) -> None:
        github = FakeGitHub(files=STACK_PR_FILES)

        amd = self.comment(github, COMMAND_ROCM_NOCACHE)

        self.assertEqual(amd.created_builds, [])
        self.assertIn(ROCM_CACHE_MARKER, github.comments[0])
        self.assertIn("@reviewer chose not to cache", github.comments[0])

    def test_refusals_leave_the_gate_failing(self) -> None:
        other_recipe = FakeGitHub(files=STACK_PR_FILES)
        other_recipe.file_shas = {("docker/docker-bake-rocm.hcl", "main"): "newer"}
        # Built with main's recipe, but the PR changed it afterwards.
        head_recipe = FakeGitHub(files=STACK_PR_FILES)
        head_recipe.file_shas = {
            (".buildkite/scripts/rocm/build.sh", "0123456789abcdef"): "changed"
        }
        # The PR changed the image after its CI last pushed one.
        head_stack = FakeGitHub(files=STACK_PR_FILES)
        head_stack.file_shas = {
            ("docker/Dockerfile.rocm_base", "0123456789abcdef"): "changed"
        }
        reused = [ci_build(meta_data={"rocm-rocm-stack": "s@d1"})]
        # The author, with CI delegated to them by an approval.
        author = FakeGitHub(
            files=STACK_PR_FILES,
            permissions={"author": "read"},
            review_decision="APPROVED",
            reviews=[{"user": {"login": "reviewer"}, "state": "APPROVED"}],
        )
        cases = [
            (other_recipe, [ci_build()], "reviewer", "before main changed them"),
            (head_recipe, [ci_build()], "reviewer", "before main changed them"),
            (head_stack, [ci_build()], "reviewer", "latest changes"),
            (FakeGitHub(files=STACK_PR_FILES), [], "reviewer", "built the ROCm"),
            (FakeGitHub(files=STACK_PR_FILES), reused, "reviewer", "built the ROCm"),
            (author, [ci_build()], "author", "Only maintainers with write access"),
        ]
        for github, builds, actor, text in cases:
            with self.subTest(text=text):
                amd = self.comment(github, ci_builds=builds, actor=actor)

                self.assertEqual(amd.created_builds, [])
                self.assertIn(text, github.comments[0])
                self.assertNotIn(ROCM_CACHE_MARKER, github.comments[0])

    def test_prs_that_keep_the_base_image_have_nothing_to_do(self) -> None:
        github = FakeGitHub(files=["vllm/foo.py"])

        amd = self.comment(github)

        self.assertEqual(amd.created_builds, [])
        self.assertIn("nothing to do", github.comments[0])
        self.assertNotIn(ROCM_CACHE_MARKER, github.comments[0])


if __name__ == "__main__":
    unittest.main()
