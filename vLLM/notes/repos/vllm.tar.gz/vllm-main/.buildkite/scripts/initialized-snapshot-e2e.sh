#!/usr/bin/env bash
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
set -Eeuo pipefail
readonly MODEL="Qwen/Qwen3-0.6B"
readonly MODEL_REVISION="c1899de289a04d12100db370d81485cdf75e47ca"
readonly EXPECTED_TOKEN_ID="12095"
readonly EXPECTED_TEXT=" Paris"
readonly CLEANUP_RESERVE_S=300
RUN_LIMIT_S="${SNAPSHOT_E2E_RUN_LIMIT_S:-3300}"
[[ "$RUN_LIMIT_S" =~ ^[1-9][0-9]{2,3}$ ]] \
    || { echo "SNAPSHOT_E2E_RUN_LIMIT_S must be a bounded decimal integer" >&2; exit 1; }
(( RUN_LIMIT_S >= CLEANUP_RESERVE_S + 60 && RUN_LIMIT_S <= 3300 )) \
    || { echo "SNAPSHOT_E2E_RUN_LIMIT_S must be between 360 and 3300" >&2; exit 1; }
readonly RUN_LIMIT_S
readonly HOST_HF_CACHE="${SNAPSHOT_E2E_HOST_HF_CACHE:-}"
HF_CACHE_MOUNT=()
if [[ -n "$HOST_HF_CACHE" ]]; then
    [[ "$HOST_HF_CACHE" == /* && -d "$HOST_HF_CACHE" ]] \
        || { echo "SNAPSHOT_E2E_HOST_HF_CACHE must be an existing absolute directory" >&2; exit 1; }
    HF_CACHE_MOUNT=(--mount "type=bind,source=$HOST_HF_CACHE,target=/e2e/hf,readonly")
    PREPARE_ARTIFACT_ROOT='install -d -m 0700 /e2e'
else
    PREPARE_ARTIFACT_ROOT='mkdir -m 0700 /e2e && mkdir -m 0700 /e2e/hf'
fi
readonly PREPARE_ARTIFACT_ROOT
if (( $# != 2 )); then
    echo "usage: $0 IMAGE_TAG BUILDKITE_COMMIT" >&2
    exit 2
fi
readonly IMAGE_TAG="$1"
readonly EXPECTED_COMMIT="$2"
readonly DEADLINE_EPOCH="$(( $(date +%s) + RUN_LIMIT_S ))"
RUN_ID="" CONTAINER_NAME="" CONTAINER_ID=""
GPU_UUID="" PORT_ONE="" PORT_TWO=""
LINK_REMAP_BASELINE=""
CHECK_CLEANUP_STATE=0
SNAPSHOT_PIDS=()
die() {
    echo "initialized snapshot E2E: $*" >&2
    exit 1
}

run() {
    local label="$1" maximum_s="$2" available limit
    shift 2
    available="$((DEADLINE_EPOCH - $(date +%s) - CLEANUP_RESERVE_S))"
    (( available > 0 )) || die "no time remains before the cleanup reserve"
    (( available < maximum_s )) && limit="$available" || limit="$maximum_s"
    echo "--- ${label} (timeout ${limit}s)" >&2
    timeout --signal=TERM --kill-after=30s "${limit}s" "$@"
}

link_remaps() {
    find /dev/shm -maxdepth 1 -name 'link_remap.*' \
        -printf '%p|%D|%i|%m|%s\n' | sort
}

gpu_pids() {
    nvidia-smi --id="$GPU_UUID" --query-compute-apps=pid \
        --format=csv,noheader,nounits | sed '/^[[:space:]]*$/d'
}

port_listeners() {
    ss -H -ltn "sport = :$1"
}

state_clean() {
    local pid port output
    for pid in "${SNAPSHOT_PIDS[@]}"; do
        [[ ! -e "/proc/$pid" ]] || return 1
    done
    output="$(gpu_pids)" || return 1
    [[ -z "$output" ]] || return 1
    output="$(link_remaps)" || return 1
    [[ "$output" == "$LINK_REMAP_BASELINE" ]] || return 1
    for port in "$PORT_ONE" "$PORT_TWO"; do
        [[ -n "$port" ]] || continue
        output="$(port_listeners "$port")" || return 1
        [[ -z "$output" ]] || return 1
    done
}

wait_clean() {
    local _attempt
    for ((_attempt = 0; _attempt < 60; _attempt++)); do
        state_clean && return 0
        sleep 1
    done
    return 1
}

container_names() {
    timeout 15s docker container ls --all --format '{{.Names}}'
}

cleanup() {
    local failed=0 names="" actual="" expected=""
    if [[ -n "$CONTAINER_NAME" ]]; then
        names="$(container_names 2>/dev/null)" || return 1
        if grep -Fxq "$CONTAINER_NAME" <<< "$names"; then
            actual="$(docker container inspect \
                --format '{{.Id}}|{{index .Config.Labels "ai.vllm.snapshot.e2e.run"}}' \
                "$CONTAINER_NAME" 2>/dev/null)" || return 1
            expected="${CONTAINER_ID:-${actual%%|*}}|$RUN_ID"
            if [[ "$actual" != "$expected" ]]; then
                echo "refusing to remove a container with mismatched identity" >&2
                failed=1
            else
                timeout 60s docker rm --force "$CONTAINER_NAME" >/dev/null \
                    || failed=1
            fi
        fi
        names="$(container_names 2>/dev/null)" || return 1
        grep -Fxq "$CONTAINER_NAME" <<< "$names" && failed=1
    fi
    if (( CHECK_CLEANUP_STATE )) && ! wait_clean; then
        echo "process, GPU, port, or link-remap residue remained" >&2
        failed=1
    fi
    return "$failed"
}

on_exit() {
    local status=$?
    trap - EXIT INT TERM
    set +e
    cleanup || status=1
    exit "$status"
}

trap on_exit EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

parse_inspect() {
    timeout 30s python3 -c '
import json, math, sys
data = json.load(sys.stdin)
model, revision, gpu_uuid, token_id, text = sys.argv[1:]
expected = {
    "boundary": "post-engine-init-reloadable-state-released",
    "model": model, "model_revision": revision,
    "gpu_uuid": gpu_uuid, "oracle_token_ids": [int(token_id)],
    "oracle_text": text,
}
bad = next((field for field, value in expected.items() if data.get(field) != value), None)
if bad:
    raise SystemExit(f"inspect field {bad} mismatch: {data.get(bad)!r}")
logprob = data.get("oracle_sampled_token_logprob")
if type(logprob) is not float or not math.isfinite(logprob):
    raise SystemExit("inspect logprob is not finite")
pids = data.get("process_tree")
if not pids:
    raise SystemExit("inspect process_tree is empty")
for pid in pids:
    print(f"pid={pid}")
print(f"oracle_logprob={logprob}")
' "$MODEL" "$MODEL_REVISION" "$GPU_UUID" "$EXPECTED_TOKEN_ID" \
        "$EXPECTED_TEXT"
}

assert_oracle() {
    local port="$1" ordinal="$2" response
    response="$(run "restore ${ordinal} public completion" 120 curl \
        --fail --silent --show-error --max-time 120 \
        --header 'Content-Type: application/json' \
        --data "{\"model\":\"${MODEL}\",\"prompt\":\"The capital of France is\",\"temperature\":0,\"seed\":0,\"min_tokens\":1,\"max_tokens\":1,\"logprobs\":0,\"return_token_ids\":true}" \
        "http://127.0.0.1:${port}/v1/completions")"
    printf '%s' "$response" | timeout 30s python3 -c '
import json, math, sys
choice = json.load(sys.stdin)["choices"][0]
token_id, text, expected, ordinal = sys.argv[1:]
values = choice["logprobs"]["token_logprobs"]
actual = float(values[0]) if len(values) == 1 else math.nan
if (choice["token_ids"] != [int(token_id)] or choice["text"] != text
        or not math.isfinite(actual) or abs(actual - float(expected)) > 1e-3):
    raise SystemExit(f"public oracle mismatch: {choice!r}")
print(f"restore={ordinal} token_id={token_id} text={text!r} logprob={actual}")
' "$EXPECTED_TOKEN_ID" "$EXPECTED_TEXT" "$INSPECT_LOGPROB" "$ordinal"
}

[[ "$(uname -s)" == "Linux" && "$(uname -m)" == "x86_64" ]] \
    || die "host must be Linux x86_64"
[[ "$EXPECTED_COMMIT" =~ ^[0-9a-f]{40}$ ]] \
    || die "BUILDKITE_COMMIT must be a full lowercase commit hash"
[[ "$(< /proc/sys/kernel/io_uring_disabled)" == "2" ]] \
    || die "kernel.io_uring_disabled must already equal 2"
run "Docker preflight" 60 docker info >/dev/null

VISIBLE_GPU="${NVIDIA_VISIBLE_DEVICES:-}"
if [[ -z "$VISIBLE_GPU" || "$VISIBLE_GPU" == "all" || "$VISIBLE_GPU" == "void" ]]; then
    VISIBLE_GPU="${CUDA_VISIBLE_DEVICES:-}"
fi
if [[ -z "$VISIBLE_GPU" || "$VISIBLE_GPU" == "all" || "$VISIBLE_GPU" == "void" ]]; then
    CDI_GPU="${BUILDKITE_PLUGIN_DOCKER_DEVICES_0:-}"
    if [[ "$CDI_GPU" == nvidia.com/gpu=* ]]; then
        VISIBLE_GPU="${CDI_GPU#nvidia.com/gpu=}"
    else
        VISIBLE_GPU=""
    fi
fi
[[ -n "$VISIBLE_GPU" && "$VISIBLE_GPU" != all && "$VISIBLE_GPU" != void \
    && "$VISIBLE_GPU" != *","* ]] \
    || die "the runner must expose exactly one selected GPU"
GPU_ROW="$(nvidia-smi --id="$VISIBLE_GPU" \
    --query-gpu=name,uuid,mig.mode.current,memory.total \
    --format=csv,noheader,nounits)"
IFS=',' read -r GPU_NAME GPU_UUID MIG_MODE GPU_MEMORY_MIB <<< "$GPU_ROW"
for variable in GPU_NAME GPU_UUID MIG_MODE GPU_MEMORY_MIB; do
    printf -v "$variable" '%s' "${!variable#"${!variable%%[![:space:]]*}"}"
done
[[ "$GPU_NAME" == *H200* && "$GPU_UUID" == GPU-* && "$MIG_MODE" == Disabled ]] \
    || die "selected device is not a full non-MIG H200: $GPU_ROW"
(( GPU_MEMORY_MIB >= 130000 )) || die "selected H200 does not expose full memory"
GPU_PIDS="$(gpu_pids)" || die "failed to inspect the selected GPU"
[[ -z "$GPU_PIDS" ]] || die "selected H200 is not idle"

RUN_ID="snapshot-e2e-$(date +%s)-$$-$RANDOM"
CONTAINER_NAME="vllm-$RUN_ID"
read -r PORT_ONE PORT_TWO < <(python3 -c 'import socket; s=[socket.socket(),socket.socket()]; [x.bind(("127.0.0.1",0)) for x in s]; print(*(x.getsockname()[1] for x in s))')
LINK_REMAP_BASELINE="$(link_remaps)" \
    || die "cannot inventory /dev/shm; check CI runner permissions"

run "pull exact candidate image" 900 docker pull --platform linux/amd64 \
    "$IMAGE_TAG" >/dev/null
IFS='|' read -r IMAGE_ID IMAGE_PLATFORM OCI_COMMIT VLLM_COMMIT < <(
    docker image inspect \
        --format '{{.Id}}|{{.Os}}/{{.Architecture}}|{{index .Config.Labels "org.opencontainers.image.revision"}}|{{index .Config.Labels "ai.vllm.build.commit"}}' \
        "$IMAGE_TAG"
)
[[ "$IMAGE_ID" =~ ^sha256:[0-9a-f]{64}$ && "$IMAGE_PLATFORM" == linux/amd64 ]] \
    || die "candidate image identity is invalid"
[[ "$OCI_COMMIT" == "$EXPECTED_COMMIT" && "$VLLM_COMMIT" == "$EXPECTED_COMMIT" ]] \
    || die "candidate image commit labels do not match"
# A failed preflight has not started any workload whose cleanup we can verify.
CHECK_CLEANUP_STATE=1
CONTAINER_ID="$(run "start exact candidate container" 90 docker run --detach \
    --name "$CONTAINER_NAME" --label "ai.vllm.snapshot.e2e.run=$RUN_ID" \
    --gpus "device=$GPU_UUID" --user 0 --privileged --pid=host --ipc=host \
    --network=host --env "CUDA_VISIBLE_DEVICES=$GPU_UUID" --env HF_HUB_DISABLE_TELEMETRY=1 \
    --env VLLM_NO_USAGE_STATS=1 \
    ${HF_CACHE_MOUNT[@]+"${HF_CACHE_MOUNT[@]}"} \
    --entrypoint sleep "$IMAGE_ID" infinity)"
[[ "$CONTAINER_ID" =~ ^[0-9a-f]{64}$ ]] || die "invalid container ID"
run "prepare private artifact root" 60 docker exec "$CONTAINER_NAME" sh -c \
    "$PREPARE_ARTIFACT_ROOT && df -Pk / | awk 'NR == 2 && \$4 >= 10485760 {ok=1} END {exit !ok}'"
run "verify snapshot runtime" 60 docker exec "$CONTAINER_NAME" sh -c \
    'criu --version; test -x /usr/local/sbin/cuda-checkpoint; test -f /usr/local/lib/criu/cuda_plugin.so'
run "verify selected CUDA device" 60 docker exec "$CONTAINER_NAME" python3 -c '
import sys, torch
if torch.cuda.device_count() != 1:
    raise SystemExit("expected exactly one visible CUDA device")
actual = str(torch.cuda.get_device_properties(0).uuid).removeprefix("GPU-")
if actual != sys.argv[1].removeprefix("GPU-"):
    raise SystemExit(f"CUDA device {actual} does not match {sys.argv[1]}")
print(f"selected_cuda_uuid=GPU-{actual}")
' "$GPU_UUID"
OFFLINE_EXEC=(docker exec --env HF_HOME=/e2e/hf --env HF_HUB_OFFLINE=1 \
    --env TRANSFORMERS_OFFLINE=1 --env VLLM_SNAPSHOT_TIMEOUT_S=900 \
    "$CONTAINER_NAME")
if [[ -n "$HOST_HF_CACHE" ]]; then
    run "validate pinned model in read-only host cache" 120 \
        "${OFFLINE_EXEC[@]}" python3 -c \
        'from pathlib import Path; from huggingface_hub import snapshot_download; import sys; p=snapshot_download(repo_id=sys.argv[1], revision=sys.argv[2], local_files_only=True); assert Path(p).name == sys.argv[2]' \
        "$MODEL" "$MODEL_REVISION"
else
    run "prefetch pinned public model" 900 docker exec --env HF_HOME=/e2e/hf \
        "$CONTAINER_NAME" python3 -c \
        'from pathlib import Path; from huggingface_hub import snapshot_download; import sys; p=snapshot_download(repo_id=sys.argv[1], revision=sys.argv[2]); assert Path(p).name == sys.argv[2]' \
        "$MODEL" "$MODEL_REVISION"
fi

run "create compact initialized snapshot" 1200 "${OFFLINE_EXEC[@]}" \
    vllm snapshot create "$MODEL" --revision "$MODEL_REVISION" \
    --tokenizer-revision "$MODEL_REVISION" --snapshot-dir /e2e/artifact \
    --dtype float16 --max-model-len 512 --gpu-memory-utilization 0.50
wait_clean || die "create left process, GPU, port, or link-remap residue"

INSPECT_JSON="$(run "inspect compact initialized snapshot" 120 \
    "${OFFLINE_EXEC[@]}" vllm snapshot inspect /e2e/artifact)"
INSPECT_RECEIPT="$(printf '%s' "$INSPECT_JSON" | parse_inspect)"
mapfile -t SNAPSHOT_PIDS < <(sed -n 's/^pid=//p' <<< "$INSPECT_RECEIPT")
INSPECT_LOGPROB="$(sed -n 's/^oracle_logprob=//p' <<< "$INSPECT_RECEIPT")"
(( ${#SNAPSHOT_PIDS[@]} > 0 )) || die "inspect returned no PIDs"
state_clean || die "create left recorded state alive"
echo "$INSPECT_RECEIPT"

run "restore compact snapshot 1" 900 "${OFFLINE_EXEC[@]}" \
    vllm snapshot restore /e2e/artifact --host 127.0.0.1 --port "$PORT_ONE"
PORT_LISTENERS="$(port_listeners "$PORT_ONE")" || die "failed to inspect restore 1 port"
[[ -n "$PORT_LISTENERS" ]] || die "restore 1 did not bind its port"
GPU_PIDS="$(gpu_pids)" || die "failed to inspect the selected GPU"
[[ -n "$GPU_PIDS" ]] || die "restore 1 did not engage the selected GPU"
assert_oracle "$PORT_ONE" 1
run "stop container after restore 1" 60 docker stop --time 20 "$CONTAINER_NAME" >/dev/null
[[ "$(docker container inspect --format '{{.Id}}' "$CONTAINER_NAME")" == "$CONTAINER_ID" ]] \
    || die "docker stop replaced the container"
wait_clean || die "restore 1 teardown left residue"

run "start the same container" 60 docker start "$CONTAINER_NAME" >/dev/null
[[ "$(docker container inspect --format '{{.Id}}' "$CONTAINER_NAME")" == "$CONTAINER_ID" ]] \
    || die "docker start replaced the container"
run "restore compact snapshot 2" 900 "${OFFLINE_EXEC[@]}" \
    vllm snapshot restore /e2e/artifact --host 127.0.0.1 --port "$PORT_TWO"
PORT_LISTENERS="$(port_listeners "$PORT_TWO")" || die "failed to inspect restore 2 port"
[[ -n "$PORT_LISTENERS" ]] || die "restore 2 did not bind its port"
GPU_PIDS="$(gpu_pids)" || die "failed to inspect the selected GPU"
[[ -n "$GPU_PIDS" ]] || die "restore 2 did not engage the selected GPU"
assert_oracle "$PORT_TWO" 2
run "stop container after restore 2" 60 docker stop --time 20 "$CONTAINER_NAME" >/dev/null
wait_clean || die "restore 2 teardown left residue"
cleanup || die "exact cleanup failed"
echo "container_id=$CONTAINER_ID restore_1_port=$PORT_ONE restore_2_port=$PORT_TWO"
echo "result=PASS"
