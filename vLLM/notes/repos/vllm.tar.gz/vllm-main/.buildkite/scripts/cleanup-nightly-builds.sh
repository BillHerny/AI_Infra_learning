#!/bin/bash

set +x
set -eo pipefail

# Clean up old nightly builds from DockerHub, keeping only the last 14 builds
# This script uses DockerHub API to list and delete old tags with specified prefix
# Tags starting with "nightly-dev" are always excluded from deletion
# Usage: cleanup-nightly-builds.sh [TAG_PREFIX] [REPO] [EXCLUDE_PREFIX]
# Example: cleanup-nightly-builds.sh "nightly-"
# Example: cleanup-nightly-builds.sh "cu130-nightly-"
# Example: cleanup-nightly-builds.sh "nightly-" "vllm/vllm-openai-rocm"
# Example: cleanup-nightly-builds.sh "nightly-" "vllm/vllm-openai-rocm" "nightly-rocm"
#   (EXCLUDE_PREFIX skips tags owned by another variant sharing TAG_PREFIX)

# Get tag prefix and repo from arguments
TAG_PREFIX="${1:-nightly-}"
REPO="${2:-vllm/vllm-openai}"
EXCLUDE_PREFIX="${3:-}"

echo "Cleaning up tags with prefix: $TAG_PREFIX in repository: $REPO"

# DockerHub API endpoint for the repository
REPO_API_URL="https://hub.docker.com/v2/namespaces/${REPO%/*}/repositories/${REPO#*/}/tags"

# Get DockerHub credentials from environment
if [ -z "$RELEASE_DOCKERHUB_TOKEN" ]; then
    echo "Error: RELEASE_DOCKERHUB_TOKEN environment variable is not set"
    exit 1
fi

if [ -z "$DOCKERHUB_USERNAME" ]; then
    echo "Error: DOCKERHUB_USERNAME environment variable is not set"
    exit 1
fi

# Get DockerHub bearer token
echo "Getting DockerHub bearer token..."
BEARER_TOKEN=$(jq -nc '{identifier: env.DOCKERHUB_USERNAME, secret: env.RELEASE_DOCKERHUB_TOKEN}' | curl -fsS \
    -H "Content-Type: application/json" \
    --data-binary @- \
    "https://hub.docker.com/v2/auth/token" | jq -er '.access_token')

if [ -z "$BEARER_TOKEN" ] || [ "$BEARER_TOKEN" = "null" ]; then
    echo "Error: Failed to get DockerHub bearer token"
    exit 1
fi

hub_request() {
    printf 'header = "Authorization: Bearer %s"\n' "$BEARER_TOKEN" | \
        curl -q --config - -fsS "$@"
}

# Function to get all tags from DockerHub
get_all_tags() {
    local page=1
    local all_tags=""
    
    while true; do
        local response
        response=$(hub_request \
            "$REPO_API_URL?page=$page&page_size=100") || return
        
        # Get both last_updated timestamp and tag name, separated by |
        # Exclude mutable architecture tags and nightly-dev tags from cleanup
        local tags
        tags=$(echo "$response" | jq -r --arg prefix "$TAG_PREFIX" --arg exclude "$EXCLUDE_PREFIX" '.results[] | select(.name | startswith($prefix)) | select($exclude == "" or (.name | startswith($exclude) | not)) | select(.name != ($prefix + "x86_64") and .name != ($prefix + "aarch64")) | select(.name | startswith("nightly-dev") | not) | "\(.last_updated)|\(.name)"') || return
        
        if [ -z "$tags" ]; then
            break
        fi
        
        all_tags="$all_tags$tags"$'\n'
        page=$((page + 1))
    done
    
    # Sort by timestamp (newest first) and extract just the tag names
    echo "$all_tags" | sort -r | cut -d'|' -f2
}

delete_tag() {
    local tag_name="$1"
    echo "Deleting tag: $tag_name"
    
    local delete_url="$REPO_API_URL/$tag_name"
    local response
    response=$(hub_request -X DELETE "$delete_url")
    
    if echo "$response" | jq -e '.detail' > /dev/null 2>&1; then
        echo "Warning: Failed to delete tag $tag_name: $(echo "$response" | jq -r '.detail')"
    else
        echo "Successfully deleted tag: $tag_name"
    fi
}

# Get all nightly- prefixed tags, sorted by last_updated timestamp (newest first)
echo "Fetching all tags from DockerHub..."
all_tags=$(get_all_tags)

if [ -z "$all_tags" ]; then
    echo "No tags found to clean up"
    exit 0
fi

# Count total tags
total_tags=$(echo "$all_tags" | wc -l)
echo "Found $total_tags tags"

# Keep only the last 14 builds (including the current one)
tags_to_keep=14
tags_to_delete=$((total_tags - tags_to_keep))

if [ $tags_to_delete -le 0 ]; then
    echo "No tags need to be deleted (only $total_tags tags found, keeping $tags_to_keep)"
    exit 0
fi

echo "Will delete $tags_to_delete old tags, keeping the newest $tags_to_keep"

# Get tags to delete (skip the first $tags_to_keep tags)
tags_to_delete_list=$(echo "$all_tags" | tail -n +$((tags_to_keep + 1)))

if [ -z "$tags_to_delete_list" ]; then
    echo "No tags to delete"
    exit 0
fi

# Delete old tags
echo "Deleting old tags..."
while IFS= read -r tag; do
    if [ -n "$tag" ]; then
        delete_tag "$tag"
        # Add a small delay to avoid rate limiting
        sleep 1
    fi
done <<< "$tags_to_delete_list"

echo "Cleanup completed successfully"
