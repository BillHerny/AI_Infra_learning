#!/bin/bash
set -euo pipefail

# Build a vLLM test image with PyTorch nightly installed.
# Called by the pipeline generator's "vLLM Against PyTorch Nightly" group.

if [[ $# -lt 5 ]]; then
  echo "Usage: $0 <registry> <repo> <commit> <branch> <image_tag>"
  exit 1
fi

REGISTRY=$1
REPO=$2
BUILDKITE_COMMIT=$3
BRANCH=$4
IMAGE_TAG=$5

# --- Arguments ---
echo "--- :mag: Arguments"
echo "REGISTRY: ${REGISTRY}"
echo "REPO: ${REPO}"
echo "BUILDKITE_COMMIT: ${BUILDKITE_COMMIT}"
echo "BRANCH: ${BRANCH}"
echo "IMAGE_TAG: ${IMAGE_TAG}"

# --- ECR login ---
echo "--- :key: ECR login"
aws ecr-public get-login-password --region us-east-1 \
  | docker login --username AWS --password-stdin "$REGISTRY"
aws ecr get-login-password --region us-east-1 \
  | docker login --username AWS --password-stdin 936637512419.dkr.ecr.us-east-1.amazonaws.com

# --- Set up buildx ---
echo "--- :docker: Setting up buildx"
docker buildx create --name vllm-builder --driver docker-container --use || true
docker buildx inspect --bootstrap
docker buildx ls

# --- Skip if image already exists ---
echo "--- :mag: Checking if image already exists"
if docker manifest inspect "$IMAGE_TAG" >/dev/null 2>&1; then
  echo "Image found: $IMAGE_TAG — skipping build"
  .buildkite/scripts/annotate-image-build.sh "$IMAGE_TAG"
  exit 0
fi
echo "Image not found, proceeding with build..."

# --- CUDA 13.2 for nightly builds ---
# Nightly CI tracks the same CUDA version as the default build
NIGHTLY_CUDA_VERSION="13.2.1"
NIGHTLY_BUILD_BASE_IMAGE="pytorch/manylinux2_28-builder:cuda13.2-9f3983c9d680f3cc243dfa0524efcb881be7869e"
# Must track ARG UBUNTU_VERSION in docker/Dockerfile. The nightly lane exists to
# run the normal pipeline against nightly torch, so it has to differ from the
# regular image in torch only -- not in the OS underneath it. This was pinned to
# 22.04 while everything else moved to 24.04, and the runtime dependency list in
# tools/install_snapshot_runtime.sh is 24.04-only (libgnutls30t64 is the 64-bit
# time_t rename and does not exist on jammy), so the nightly build failed with
# "E: Unable to locate package libgnutls30t64" while regular CI stayed green on
# a cached layer.
NIGHTLY_UBUNTU_VERSION="24.04"
NIGHTLY_FINAL_BASE_IMAGE="nvidia/cuda:${NIGHTLY_CUDA_VERSION}-base-ubuntu${NIGHTLY_UBUNTU_VERSION}"

echo "--- :docker: Building torch nightly image (CUDA ${NIGHTLY_CUDA_VERSION})"
# Provenance labels match the bake `_labels` target in docker/docker-bake.hcl;
# the initialized-snapshot E2E refuses images whose commit labels differ.
docker buildx build --file docker/Dockerfile \
  --build-arg max_jobs=16 \
  --build-arg buildkite_commit="$BUILDKITE_COMMIT" \
  --build-arg USE_SCCACHE=1 \
  --build-arg PYTORCH_NIGHTLY=1 \
  --build-arg CUDA_VERSION="${NIGHTLY_CUDA_VERSION}" \
  --build-arg BUILD_BASE_IMAGE="${NIGHTLY_BUILD_BASE_IMAGE}" \
  --build-arg FINAL_BASE_IMAGE="${NIGHTLY_FINAL_BASE_IMAGE}" \
  --build-arg torch_cuda_arch_list="8.0 8.9 9.0 10.0 12.0" \
  --label "org.opencontainers.image.revision=${BUILDKITE_COMMIT}" \
  --label "ai.vllm.build.commit=${BUILDKITE_COMMIT}" \
  --label "ai.vllm.build.pipeline=${BUILDKITE_PIPELINE_SLUG:-local}" \
  --label "ai.vllm.build.url=${BUILDKITE_BUILD_URL:-}" \
  --tag "$IMAGE_TAG" \
  --push \
  --target test \
  --progress plain .

echo "--- :white_check_mark: Torch nightly image build complete: $IMAGE_TAG"

.buildkite/scripts/annotate-image-build.sh "$IMAGE_TAG"
